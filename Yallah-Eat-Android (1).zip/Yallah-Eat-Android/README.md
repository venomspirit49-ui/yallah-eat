# Yallah Eat for Android

Android version of the Yallah Eat food discovery prototype. A small Java Android app bundles the existing interface in a WebView, so the demo does not need a hosted website. It preserves menus, search, favorites, cart, test orders, courier registration and the simulated delivery journey.

**This deliverable is Android source code. No APK has been built or tested on a device in the authoring environment:** the Android SDK is unavailable and network downloads could not complete. The app remains a prototype: no real order is sent, no courier is hired, and no live delivery is dispatched.

## Build an APK

### Android Studio

1. Extract the project and open this directory in Android Studio.
2. Install Android SDK Platform 36 and Android SDK Build-Tools 36.0.0 through SDK Manager. Use JDK 17 or 21 for Gradle.
3. Allow Gradle sync to download the pinned build tools. If Studio asks for a Gradle installation, select Gradle 8.13.
4. Select **Build → Generate App Bundles or APKs → Generate APKs**, or run the `assembleDebug` Gradle task.

The debug APK is written to:

```text
app/build/outputs/apk/debug/app-debug.apk
```

Install it on an Android 8.0 or later device with a current Android System WebView. Android Studio can run the app directly on a connected device or emulator. For a command-line installation:

```sh
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

### Command line

Install a full JDK 17 or 21 and the Android SDK. Set `ANDROID_HOME` to your SDK directory, or create an untracked `local.properties` containing `sdk.dir=/absolute/path/to/your/sdk`.

On macOS or Linux:

```sh
chmod +x gradlew
./gradlew :app:assembleDebug
```

On Windows:

```bat
gradlew.bat :app:assembleDebug
```

The included `gradlew` launchers use a small, readable Java bootstrap rather than a bundled Gradle wrapper JAR. The first run downloads the official Gradle distribution, checks its published SHA-256 checksum and caches it. This requires a full JDK and internet access. The Android build also downloads its declared tools on first use. Do not replace the fixed download locations with untrusted mirrors.

### Cloud build

The included `.github/workflows/android.yml` can build the APK on GitHub Actions after you place this project in a repository. In **Actions**, select the Android workflow and choose **Run workflow**. A successful run provides an artifact named **Yallah-Eat-debug** containing the debug APK.

No repository has been created or pushed, and this workflow has not been run. A debug APK is for testing. A store release requires your own signing key, release configuration and review of the actual production service; keep signing secrets outside source control.

## What works locally

- Eight fictional Casablanca restaurants and their demo menus.
- Search, cuisine filters, favorites, cart and order history.
- A local courier profile, availability switch and simulated pickup/delivery steps using this installation’s test orders.
- A restaurant application draft stored on this device.
- Embedded food illustrations when the remote food photos cannot load.

The Android installation has its own local data. It does **not** import orders, favorites or courier profiles previously entered in a desktop/mobile browser. Uninstalling the app or clearing its data removes these records. Android backup is disabled.

## Features that use the internet

- Food photos from Unsplash and fonts from Google Fonts.
- A GPS-triggered OpenStreetMap/Overpass search for public food addresses within 3.5 km.
- The embedded OpenStreetMap map and external map directions.

Location access is requested only when you choose the GPS feature. Approximate location is sufficient; precise location is optional. If permission is denied, the bundled Casablanca neighborhood demo remains available. Public directory results may lack menus, telephone numbers, opening hours or delivery information; confirm these details with the establishment.

Telephone links open the Android dialer for you to confirm the call. Directions open an external map/browser app. The app does not request permission to place calls directly.

## Update the bundled interface

The editable HTML, CSS and JavaScript are included in `web/public/`. After editing them, rebuild and synchronize the bundled page:

```sh
node web/build.mjs
python3 tools/sync-web.py web/outputs/Yallah-Eat.html
```

You can also import a newer standalone export from the original web project:

```sh
python3 tools/sync-web.py /path/to/Yallah-Eat.html
```

The prepared page is stored at `app/src/main/assets/index.html`. Rebuild the Android app after updating it. The app serves this bundled content from its intercepted local HTTPS origin, `https://appassets.androidplatform.net/assets/index.html`; it does not depend on a live website at that address.

These source-update commands require Node.js and Python 3. They are not needed just to build the included, already-bundled Android app. See `TESTING.md` for offline checks and the device checklist.

## Toolchain and scope

- Android minimum SDK: 26; compile and target SDK: 36.
- Android Gradle Plugin: 8.13.0; Gradle: 8.13; Java language level: 17.
- Platform Android APIs and WebView; no third-party Android runtime library is required.
- No JavaScript-to-native interface, file access or cleartext network traffic.

The conversion packages the existing demo; it does not add shared accounts, a backend database, payments, restaurant verification, notifications, background courier tracking or real dispatch. Those services must be implemented and tested before commercial operation. See [PRIVACY.md](PRIVACY.md) for the prototype’s data behavior.
