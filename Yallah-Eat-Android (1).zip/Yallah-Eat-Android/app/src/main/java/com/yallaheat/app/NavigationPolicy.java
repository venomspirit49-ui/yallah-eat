package com.yallaheat.app;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Locale;

/** Pure URL rules shared by Android navigation, interception and permission checks. */
public final class NavigationPolicy {
    public static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    public static final String APP_PATH = "/assets/index.html";
    public static final String APP_URL = APP_ORIGIN + APP_PATH;

    public enum ExternalAction { WEB, DIAL, BLOCK }

    private NavigationPolicy() { }

    private static URI parse(String value) {
        if (value == null || value.length() > 8192) return null;
        try { return new URI(value); }
        catch (URISyntaxException ignored) { return null; }
    }

    public static boolean isAppOrigin(String value) {
        URI uri = parse(value);
        return uri != null && "https".equalsIgnoreCase(uri.getScheme())
                && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())
                && uri.getRawUserInfo() == null && (uri.getPort() == -1 || uri.getPort() == 443);
    }

    public static boolean isBundledPage(String value) {
        URI uri = parse(value);
        return isAppOrigin(value) && uri != null && APP_PATH.equals(uri.getRawPath())
                && uri.getRawQuery() == null;
    }

    public static boolean isAllowedRemote(String value) {
        URI uri = parse(value);
        if (uri == null || !"https".equalsIgnoreCase(uri.getScheme()) || uri.getHost() == null
                || uri.getRawUserInfo() != null || (uri.getPort() != -1 && uri.getPort() != 443)) return false;
        String host = uri.getHost().toLowerCase(Locale.ROOT);
        return host.equals("images.unsplash.com") || host.equals("fonts.googleapis.com")
                || host.equals("fonts.gstatic.com") || host.equals("overpass-api.de")
                || host.equals("openstreetmap.org") || host.endsWith(".openstreetmap.org");
    }

    public static String phoneNumber(String value) {
        URI uri = parse(value);
        if (uri == null || !"tel".equalsIgnoreCase(uri.getScheme()) || uri.getRawFragment() != null) return null;
        String phone = uri.getSchemeSpecificPart();
        return phone != null && phone.matches("\\+?[0-9]{8,15}") ? phone : null;
    }

    public static ExternalAction externalAction(String value) {
        if (isAppOrigin(value)) return ExternalAction.BLOCK;
        if (phoneNumber(value) != null) return ExternalAction.DIAL;
        URI uri = parse(value);
        if (uri != null && "https".equalsIgnoreCase(uri.getScheme()) && uri.getHost() != null
                && uri.getRawUserInfo() == null) return ExternalAction.WEB;
        return ExternalAction.BLOCK;
    }
}
