package com.yallaheat.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.window.OnBackInvokedCallback;
import android.window.OnBackInvokedDispatcher;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public final class MainActivity extends Activity {
    private static final int LOCATION_REQUEST = 210;
    private static final int PAPER = Color.rgb(255, 254, 251);
    private static final int GREEN = Color.rgb(36, 85, 61);
    private static final String CSP = "default-src 'none'; script-src 'unsafe-inline'; "
            + "style-src 'unsafe-inline' https://fonts.googleapis.com; "
            + "font-src https://fonts.gstatic.com data:; img-src data: https://images.unsplash.com; "
            + "connect-src https://overpass-api.de; frame-src https://www.openstreetmap.org; "
            + "base-uri 'none'; form-action 'none'; object-src 'none'";

    private WebView webView;
    private ProgressBar progress;
    private LinearLayout errorView;
    private GeolocationPermissions.Callback pendingLocation;
    private String pendingOrigin;
    private boolean destroyed;
    private boolean backInProgress;
    private OnBackInvokedCallback backCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(PAPER);
        configureWindow(root);

        webView = new WebView(this);
        webView.setBackgroundColor(PAPER);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        configureWebView();

        progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setProgressTintList(ColorStateList.valueOf(GREEN));
        progress.setProgressBackgroundTintList(ColorStateList.valueOf(PAPER));
        root.addView(progress, new FrameLayout.LayoutParams(-1, dp(3), Gravity.TOP));
        errorView = makeErrorView();
        root.addView(errorView, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        if (Build.VERSION.SDK_INT >= 33) {
            backCallback = this::handleBack;
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(
                    OnBackInvokedDispatcher.PRIORITY_DEFAULT, backCallback);
        }
        boolean restored = savedInstanceState != null && webView.restoreState(savedInstanceState) != null;
        if (!restored || !NavigationPolicy.isBundledPage(webView.getUrl())) loadApp();
    }

    private void configureWindow(FrameLayout root) {
        Window window = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            window.setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view, insets) -> {
                Insets safe = insets.getInsets(WindowInsets.Type.systemBars()
                        | WindowInsets.Type.displayCutout() | WindowInsets.Type.ime());
                view.setPadding(safe.left, safe.top, safe.right, safe.bottom);
                return WindowInsets.CONSUMED;
            });
            WindowInsetsController controller = window.getInsetsController();
            if (controller != null) controller.setSystemBarsAppearance(
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS,
                    WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
                            | WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS);
        } else {
            window.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true); // Only the bundled, authored app executes in the main frame.
        settings.setDomStorageEnabled(true);
        settings.setGeolocationEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSafeBrowsingEnabled(true);
        settings.setTextZoom(Math.round(getResources().getConfiguration().fontScale * 100));
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, false);
        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);

        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (NavigationPolicy.isAppOrigin(url)) {
                    if (NavigationPolicy.isBundledPage(url) && "GET".equals(request.getMethod())) {
                        try {
                            WebResourceResponse page = new WebResourceResponse("text/html", "UTF-8",
                                    getAssets().open("index.html"));
                            Map<String, String> headers = new HashMap<>();
                            headers.put("Content-Security-Policy", CSP);
                            headers.put("Referrer-Policy", "no-referrer");
                            headers.put("X-Content-Type-Options", "nosniff");
                            headers.put("Cache-Control", "no-store");
                            page.setResponseHeaders(headers);
                            return page;
                        } catch (IOException error) {
                            return blockedResponse(500, "Bundled page unavailable");
                        }
                    }
                    return blockedResponse(404, "Not found");
                }
                return NavigationPolicy.isAllowedRemote(url) ? null : blockedResponse(403, "Blocked");
            }

            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame()) return false;
                String url = request.getUrl().toString();
                if (NavigationPolicy.isBundledPage(url)) return false;
                if (request.hasGesture()) openExternal(url);
                return true;
            }

            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && NavigationPolicy.isAppOrigin(request.getUrl().toString())) showError();
            }

            @Override public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse error) {
                if (request.isForMainFrame() && NavigationPolicy.isAppOrigin(request.getUrl().toString())) showError();
            }

            @Override public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel();
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onProgressChanged(WebView view, int value) {
                if (progress == null) return;
                progress.setProgress(value);
                progress.setVisibility(value >= 100 ? View.GONE : View.VISIBLE);
            }

            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (destroyed || !NavigationPolicy.isAppOrigin(origin)
                        || !NavigationPolicy.isBundledPage(webView.getUrl())) {
                    callback.invoke(origin, false, false);
                    return;
                }
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                    return;
                }
                cancelPendingLocation();
                pendingLocation = callback;
                pendingOrigin = origin;
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, LOCATION_REQUEST);
            }

            @Override public void onPermissionRequest(PermissionRequest request) {
                request.deny(); // No camera, microphone or other web permissions are used.
            }
        });
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_REQUEST && pendingLocation != null) {
            boolean allowed = !destroyed && hasLocationPermission()
                    && NavigationPolicy.isBundledPage(webView.getUrl());
            pendingLocation.invoke(pendingOrigin, allowed, false);
            pendingLocation = null;
            pendingOrigin = null;
        }
    }

    private void cancelPendingLocation() {
        if (pendingLocation != null) pendingLocation.invoke(pendingOrigin, false, false);
        pendingLocation = null;
        pendingOrigin = null;
    }

    private void openExternal(String url) {
        NavigationPolicy.ExternalAction action = NavigationPolicy.externalAction(url);
        if (action == NavigationPolicy.ExternalAction.BLOCK) return;
        Intent intent = action == NavigationPolicy.ExternalAction.DIAL
                ? new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + NavigationPolicy.phoneNumber(url)))
                : new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE);
        try { startActivity(intent); }
        catch (ActivityNotFoundException | SecurityException ignored) {
            Toast.makeText(this, R.string.external_unavailable, Toast.LENGTH_SHORT).show();
        }
    }

    private static WebResourceResponse blockedResponse(int status, String reason) {
        return new WebResourceResponse("text/plain", "UTF-8", status, reason, new HashMap<>(),
                new ByteArrayInputStream(reason.getBytes(StandardCharsets.UTF_8)));
    }

    private void loadApp() {
        errorView.setVisibility(View.GONE);
        webView.setVisibility(View.VISIBLE);
        webView.loadUrl(NavigationPolicy.APP_URL);
    }

    private LinearLayout makeErrorView() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(dp(28), dp(28), dp(28), dp(28));
        panel.setBackgroundColor(PAPER);
        TextView title = new TextView(this);
        title.setText(R.string.page_error_title);
        title.setTextSize(22);
        title.setTextColor(GREEN);
        title.setGravity(Gravity.CENTER);
        panel.addView(title);
        TextView message = new TextView(this);
        message.setText(R.string.page_error_message);
        message.setTextSize(14);
        message.setTextColor(GREEN);
        message.setGravity(Gravity.CENTER);
        message.setPadding(0, dp(16), 0, dp(22));
        panel.addView(message);
        Button retry = new Button(this);
        retry.setText(R.string.retry);
        retry.setOnClickListener(view -> loadApp());
        panel.addView(retry);
        panel.setVisibility(View.GONE);
        return panel;
    }

    private void showError() {
        if (destroyed) return;
        progress.setVisibility(View.GONE);
        errorView.setVisibility(View.VISIBLE);
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void handleBack() {
        if (destroyed || backInProgress) return;
        if (errorView.getVisibility() == View.VISIBLE) { finish(); return; }
        backInProgress = true;
        webView.evaluateJavascript("(function(){var dialog=document.querySelector('dialog[open]');"
                + "if(dialog){dialog.close();return true;}return false;})()", result -> {
            backInProgress = false;
            if (destroyed || "true".equals(result)) return;
            if (webView.canGoBack()) webView.goBack(); else finish();
        });
    }

    @SuppressWarnings("deprecation")
    @Override public void onBackPressed() { handleBack(); }

    @Override protected void onSaveInstanceState(Bundle state) {
        webView.saveState(state);
        super.onSaveInstanceState(state);
    }

    @Override protected void onPause() {
        webView.onPause();
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (webView != null) webView.onResume();
    }

    @Override protected void onDestroy() {
        destroyed = true;
        cancelPendingLocation();
        if (Build.VERSION.SDK_INT >= 33 && backCallback != null)
            getOnBackInvokedDispatcher().unregisterOnBackInvokedCallback(backCallback);
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            if (webView.getParent() instanceof ViewGroup) ((ViewGroup) webView.getParent()).removeView(webView);
            webView.destroy();
        }
        super.onDestroy();
    }
}
