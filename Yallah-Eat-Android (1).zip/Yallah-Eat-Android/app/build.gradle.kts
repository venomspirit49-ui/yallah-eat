plugins {
    id("com.android.application")
}

android {
    namespace = "com.yallaheat.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.yallaheat.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "1.0.0-demo"
    }

    buildFeatures {
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    lint {
        abortOnError = true
        checkReleaseBuilds = true
    }
}
