# Verification and device checklist

Offline checks in this workspace:

- All Android XML files parse successfully.
- The existing demo was bundled as one HTML asset with no local server or separate JavaScript dependency.
- Its inline JavaScript passes Node syntax validation.
- Native navigation policy tests run against the actual Java implementation on the JVM.
- The custom Gradle launcher compiles and its offline runtime/help commands work.

An Android SDK is not installed here and network connections are unavailable. **No APK, Android lint result, emulator result, or device pass is claimed.** The included workflow has not been uploaded or run. Use Android Studio or the included build workflow to compile and run the app.

To repeat the offline checks with Python 3 and a full JDK:

```sh
python3 tests/check-project.py
javac -d /tmp/yallah-policy-tests app/src/main/java/com/yallaheat/app/NavigationPolicy.java tests/NavigationPolicyTest.java
java -cp /tmp/yallah-policy-tests com.yallaheat.app.NavigationPolicyTest
./gradlew --check-runtime
```

The navigation suite passed 98 checks. Java parsing and pure policy compilation do not establish that the Android framework code builds against the SDK.

Before distributing an APK, verify on Android 8+, Android 12 and Android 16 with an updated Android System WebView:

1. Open offline: the bundled catalogue and illustration fallback appear; search, filters, favorites and menus work.
2. Add menu items, open the cart from both entry points and switch delivery/pickup. Delivery fees and the address field agree with the chosen mode.
3. Place a test delivery, create a demo courier, go online, accept, retrieve and complete it. Check the customer history.
4. Close and reopen the app; local favorites, cart, orders and profile remain. Rotate a screen and open the keyboard; controls stay reachable.
5. Tap GPS, test deny/approximate/precise, then test location services disabled and an unavailable network. Manual district selection remains available.
6. Open the map; the embedded map stays inside the app. Tap directions and telephone on a real sourced address; browser/maps or dialer opens. Missing handler produces a message.
7. Press Back with an open menu or location dialog: the dialog closes before the app exits. Check gesture navigation and keyboard behavior.
8. Clear app storage; the demonstration data resets. Check screen reader labels and enlarged text.

The debug APK is for testing. A signed release and a production backend, verified merchant data and delivery operations are separate requirements for launch.
