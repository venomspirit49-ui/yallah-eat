package com.yallaheat.app;

/** Runs without Android framework classes: java com.yallaheat.app.NavigationPolicyTest. */
public final class NavigationPolicyTest {
    private static int checks;

    private static void expect(boolean result, String message) {
        checks++;
        if (!result) throw new AssertionError(message);
    }

    private static void action(String value, NavigationPolicy.ExternalAction expected) {
        expect(NavigationPolicy.externalAction(value) == expected, "Unexpected action for " + value);
    }

    public static void main(String[] args) {
        String origin = NavigationPolicy.APP_ORIGIN;
        String page = NavigationPolicy.APP_URL;

        expect(NavigationPolicy.isAppOrigin(origin), "Exact origin must be trusted");
        expect(NavigationPolicy.isAppOrigin(origin + "/"), "Geolocation origin may include trailing slash");
        expect(NavigationPolicy.isAppOrigin("HTTPS://APPASSETS.ANDROIDPLATFORM.NET:443"), "Default HTTPS port and host case must work");
        expect(NavigationPolicy.isBundledPage(page), "Bundled page must load");
        expect(NavigationPolicy.isBundledPage(page + "#restaurants"), "Local hash links must work");
        expect(NavigationPolicy.isBundledPage(origin + ":443/assets/index.html"), "Explicit default port must work");

        for (String value : new String[] {
                null, "", "not a url", "http://appassets.androidplatform.net/assets/index.html",
                "https://appassets.androidplatform.net.evil.test/assets/index.html",
                "https://evilappassets.androidplatform.net/assets/index.html",
                "https://appassets.androidplatform.net@evil.test/assets/index.html",
                "https://evil.test@appassets.androidplatform.net/assets/index.html",
                "https://appassets.androidplatform.net:444/assets/index.html",
                "https://appassets.androidplatform.net./assets/index.html",
                "https://appassets%2eandroidplatform.net/assets/index.html",
                "file:///android_asset/index.html", "javascript:alert(1)"
        }) {
            expect(!NavigationPolicy.isAppOrigin(value), "Spoofed/invalid origin accepted: " + value);
            expect(!NavigationPolicy.isBundledPage(value), "Spoofed/invalid page accepted: " + value);
        }

        for (String suffix : new String[] {
                "/", "/assets/", "/assets/other.html", "/assets/../index.html",
                "/assets/./index.html", "/assets/%2e%2e/index.html",
                "/assets/index%2ehtml", "/assets%2findex.html", "/assets/index.html/",
                "/assets/index.html?source=remote", "/assets//index.html"
        }) expect(!NavigationPolicy.isBundledPage(origin + suffix), "Wrong asset path accepted: " + suffix);

        for (String value : new String[] {
                "https://images.unsplash.com/photo-123?auto=format",
                "https://fonts.googleapis.com/css2?family=Manrope",
                "https://fonts.gstatic.com/font.woff2",
                "https://overpass-api.de/api/interpreter?data=test",
                "https://openstreetmap.org/", "https://www.openstreetmap.org/export/embed.html",
                "https://tile.openstreetmap.org/1/2/3.png",
                "https://a.tile.openstreetmap.org:443/1/2/3.png"
        }) expect(NavigationPolicy.isAllowedRemote(value), "Required remote host blocked: " + value);

        for (String value : new String[] {
                null, "", "http://overpass-api.de/api/interpreter",
                "https://evilopenstreetmap.org/", "https://openstreetmap.org.evil.test/",
                "https://images.unsplash.com.evil.test/", "https://other.unsplash.com/",
                "https://www.openstreetmap.org@evil.test/", "https://evil@www.openstreetmap.org/",
                "https://overpass-api.de:8443/", "https://google.com/", "data:text/html,test",
                "file:///android_asset/index.html", "javascript:alert(1)"
        }) expect(!NavigationPolicy.isAllowedRemote(value), "Remote boundary bypass accepted: " + value);

        action("https://www.google.com/maps/search/?api=1&query=33,-7", NavigationPolicy.ExternalAction.WEB);
        action("https://www.openstreetmap.org/", NavigationPolicy.ExternalAction.WEB);
        action("tel:+212612345678", NavigationPolicy.ExternalAction.DIAL);
        action("tel:0612345678", NavigationPolicy.ExternalAction.DIAL);
        action("tel:%2B212612345678", NavigationPolicy.ExternalAction.DIAL);
        for (String value : new String[] {
                page, origin + "/another-page", "javascript:alert(1)", "http://example.com/",
                "intent://maps/#Intent;scheme=geo;end", "file:///sdcard/example.html",
                "content://example/provider", "data:text/html,test", "https://user@example.com/",
                "tel:123", "tel:+212612345678;ext=1", "tel:+212612345678?body=hi",
                "tel:*123%23", "tel:+212612345678#fragment", "tel:+212 612345678"
        }) action(value, NavigationPolicy.ExternalAction.BLOCK);

        expect("+212612345678".equals(NavigationPolicy.phoneNumber("tel:+212612345678")), "International number changed");
        expect("0612345678".equals(NavigationPolicy.phoneNumber("TEL:0612345678")), "Local number changed");
        for (String value : new String[] {
                null, "tel:", "tel:1234567", "tel:1234567890123456", "tel:++212612345678",
                "tel:+212-612345678", "tel:06(12)345678", "tel:abc12345678", "sms:0612345678"
        }) expect(NavigationPolicy.phoneNumber(value) == null, "Unsafe telephone accepted: " + value);

        String oversized = "https://www.openstreetmap.org/" + new String(new char[8200]).replace('\0', 'a');
        expect(!NavigationPolicy.isAllowedRemote(oversized), "Oversized URL accepted");
        action(oversized, NavigationPolicy.ExternalAction.BLOCK);
        System.out.println("PASS: " + checks + " navigation, origin, remote-host and telephone checks.");
    }
}
