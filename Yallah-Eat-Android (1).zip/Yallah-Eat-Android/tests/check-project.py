#!/usr/bin/env python3
"""Offline structural validation. Does not replace an Android SDK build."""
from html.parser import HTMLParser
from pathlib import Path
import re
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
NS = '{http://schemas.android.com/apk/res/android}'
for resource in (ROOT / 'app/src/main').rglob('*.xml'):
    ET.parse(resource)
manifest = ET.parse(ROOT / 'app/src/main/AndroidManifest.xml').getroot()
application = manifest.find('application')
assert application.get(NS+'usesCleartextTraffic') == 'false'
assert application.get(NS+'allowBackup') == 'false'
assert manifest.find('application/activity').get(NS+'exported') == 'true'
permissions = {item.get(NS+'name') for item in manifest.findall('uses-permission')}
assert permissions == {'android.permission.INTERNET','android.permission.ACCESS_COARSE_LOCATION','android.permission.ACCESS_FINE_LOCATION'}
html = (ROOT / 'app/src/main/assets/index.html').read_text()
assert 'YallahData' in html and 'YallahDialogs' in html
assert 'target="_blank"' not in html
assert 'viewport-fit=cover' in html
assert 'android-app-note' in html
assert 'src="/app.js"' not in html and '/images/' not in html

class Inspector(HTMLParser):
    ids = []
    scripts = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs: self.ids.append(attrs['id'])
        if tag == 'script': self.scripts.append(attrs)

inspector = Inspector()
inspector.feed(html)
assert len(inspector.ids) == len(set(inspector.ids)), 'Duplicate HTML IDs'
assert len(inspector.scripts) == 1 and 'src' not in inspector.scripts[0]
assert all(control in inspector.ids for control in ('app-dialog','location-dialog','cart-button','gps-button','courier-button'))
java = (ROOT / 'app/src/main/java/com/yallaheat/app/MainActivity.java').read_text()
assert 'addJavascriptInterface' not in java
assert 'setAllowFileAccess(false)' in java and 'setAllowContentAccess(false)' in java
assert 'handler.cancel()' in java
print('PASS: XML, manifest permissions, bundled app, asset independence and native safety settings.')
