@echo off
setlocal
for %%I in ("%~dp0.") do set "APP_ROOT=%%~fI"
if defined JAVA_HOME (
    set "JAVA_RUN=%JAVA_HOME%\bin\java.exe"
) else (
    set "JAVA_RUN=java"
)
"%JAVA_RUN%" "-Dyallah.project.dir=%APP_ROOT%" "%APP_ROOT%\tools\GradleBootstrap.java" %*
exit /b %ERRORLEVEL%
