# Yallah Eat Android prototype — data behavior

This document describes the bundled demonstration app. It is a technical disclosure for testing, not a claim that a future delivery business is ready for production or satisfies every applicable legal requirement.

## Data kept on your device

Favorites, cart contents, test orders, checkout contact/address details, the demo courier profile and the restaurant application draft are stored in this Android installation’s WebView storage. They are not shared with another customer, restaurant or courier, and are not imported from a browser installation of the demo.

No real order is transmitted by the demo. Courier missions and order status changes are local simulations. There is no application backend receiving these records, and no analytics or advertising tracking code is included.

You can remove the stored records through Android **Settings → Apps → Yallah Eat → Storage → Clear storage**, or by uninstalling the app. Android backup is disabled for this app. Data can remain available on the device until cleared; avoid entering sensitive real information while testing.

## Optional location use

The app requests Android location permission when you choose **Autour de moi** or the equivalent GPS control. Approximate location is accepted; you can decline location access and continue using the bundled Casablanca demo neighborhoods.

When you request nearby addresses, the obtained coordinates are sent to the Overpass service at `overpass-api.de` as part of a restaurant search. Opening the embedded map sends the displayed map bounds and marker coordinates to OpenStreetMap. The app does not implement continuous or background location tracking.

## External services and apps

- **Unsplash:** remote food photos. Embedded illustrations are used when photos fail to load.
- **Google Fonts:** interface fonts; system fonts remain available if the service cannot load.
- **Overpass and OpenStreetMap:** public food-address search and map display. Public records can be incomplete or outdated.
- **External map/browser apps:** opened when you choose directions. The destination coordinates/address are passed to the selected service.
- **Android dialer:** opened when you choose a restaurant’s available phone number. You decide whether to make the call.

Network services receive information needed to fulfill a request, such as the device’s IP address and request metadata. The app does not attach locally entered customer names, phone numbers or delivery addresses to its photo, font or directory requests. External services and apps have their own data policies.

## Before a real launch

A production version would need an identified service operator and contact channel, an actual privacy policy matching its backend and business operations, access controls, retention/deletion procedures and clear disclosures for payments, restaurant/courier communications and any delivery tracking. Reassess this document whenever those capabilities are added.
