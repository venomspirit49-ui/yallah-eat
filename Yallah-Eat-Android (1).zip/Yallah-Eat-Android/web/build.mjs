import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
const source = path.join(root, 'public');
const dist = path.join(root, 'dist');
const outputs = path.join(root, 'outputs');
fs.mkdirSync(outputs, { recursive: true });
fs.cpSync(source, dist, { recursive: true });

const read = name => fs.readFileSync(path.join(source, name), 'utf8');
function wrap(file, variable, exports, imports = {}) {
  let code = read(file).replace(/^import\s+\{([^}]+)\}\s+from\s+['"]([^'"]+)['"];?\s*$/gm, (_, names, module) => {
    if (!imports[module]) throw new Error(`Unknown import ${module}`);
    return `const {${names}} = ${imports[module]};`;
  }).replace(/^export\s+/gm, '');
  return `const ${variable} = (() => {\n${code}\nreturn {${exports.join(',')}};\n})();\n`;
}
let code = wrap('media.js', 'YallahMedia', ['images']);
code += wrap('data.js', 'YallahData', ['restaurants','districts','money','escapeHTML','getStore','setStore','haversine'], { './media.js':'YallahMedia' });
code += wrap('dialogs.js', 'YallahDialogs', ['openRestaurant','openCart','openCourier','openOrders','openPartner'], { './data.js':'YallahData' });
code += wrap('app.js', 'YallahApp', [], { './data.js':'YallahData', './dialogs.js':'YallahDialogs', './media.js':'YallahMedia' });
fs.writeFileSync(path.join(outputs, 'bundle-check.js'), code);
let html = read('index.html')
  .replace('<link rel="stylesheet" href="/style.css"><link rel="stylesheet" href="/dialogs.css">', `<style>${read('style.css')}\n${read('dialogs.css')}</style>`)
  .replace('href="/favicon.svg"', `href="data:image/svg+xml,${encodeURIComponent(read('favicon.svg'))}"`)
  .replace('<script type="module" src="/app.js"></script>', `<script>${code.replaceAll('</script', '<\\/script')}</script>`)
  .replaceAll('href="/"', 'href="#"');
fs.writeFileSync(path.join(outputs, 'Yallah-Eat.html'), html);
fs.copyFileSync(path.join(root, 'CONCEPT.md'), path.join(dist, 'CONCEPT.md'));
console.log('Prepared dist/ and outputs/Yallah-Eat.html');
