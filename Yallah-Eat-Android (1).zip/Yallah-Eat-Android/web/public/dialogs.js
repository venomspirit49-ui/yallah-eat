import { restaurants, money, escapeHTML, getStore, setStore } from './data.js';

const e = value => escapeHTML(String(value ?? ''));
const icons = {
  close: '<path d="m6 6 12 12M18 6 6 18"/>',
  bag: '<path d="M6 7h12l2 13H4L6 7Z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>',
  pin: '<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  arrow: '<path d="M4 12h16m-6-6 6 6-6 6"/>',
  bike: '<circle cx="5" cy="16" r="4"/><circle cx="19" cy="16" r="4"/><path d="m5 16 5-10 6 10H5m4-10h4m2-3h3l1 13"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  phone: '<path d="m7 3 3 5-3 3c2 3 3 4 6 6l3-3 5 3c0 3-2 5-5 4C9 19 5 15 3 8 2 5 4 3 7 3Z"/>',
};
const icon = name => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.arrow}</svg>`;
const button = (label, action, type = 'primary', extra = '') => `<button type="button" class="d-button d-${type}" data-action="${action}" ${extra}>${label}</button>`;
const notice = (text, kind = '') => `<div class="d-notice ${kind}">${text}</div>`;
let currentRestaurant = null;

function modal() { return document.getElementById('app-dialog'); }
function mount(title, content, { wide = false, subtitle = '' } = {}) {
  const d = modal();
  d.className = `yallah-dialog ${wide ? 'd-wide' : ''}`;
  d.innerHTML = `<div class="d-shell"><div class="d-top"><div><span class="d-eyebrow">YALLAH EAT</span><h2 id="dialog-title">${e(title)}</h2>${subtitle ? `<p class="d-subtitle">${e(subtitle)}</p>` : ''}</div><button type="button" class="d-close" aria-label="Fermer">${icon('close')}</button></div><div class="d-content">${content}</div><div class="d-toast" role="status" aria-live="polite"></div></div>`;
  d.setAttribute('aria-labelledby', 'dialog-title');
  d.querySelector('.d-close').onclick = () => d.close();
  d.onclick = event => { if (event.target === d) d.close(); };
  if (!d.open) d.showModal();
  else d.querySelector('.d-close').focus({ preventScroll: true });
  d.querySelector('.d-content').scrollTop = 0;
  return d;
}
function toast(message) {
  const node = modal().querySelector('.d-toast');
  node.textContent = message;
  node.classList.add('is-visible');
  clearTimeout(toast.timer);
  toast.timer = setTimeout(() => node.classList.remove('is-visible'), 2800);
}
function updateCart(cart) {
  const saved = setStore('cart', cart);
  window.dispatchEvent(new CustomEvent('yallah:cart'));
  if (saved === false) toast('Le navigateur empêche l’enregistrement. Activez le stockage local pour tester le panier.');
  return saved !== false;
}
function readCart() {
  const value = getStore('cart', null);
  if (!value || typeof value !== 'object' || typeof value.restaurantId !== 'string' || !Array.isArray(value.items)) return null;
  const items = value.items.filter(item => item && typeof item.id === 'string' && typeof item.name === 'string' && Number.isFinite(item.price) && item.price >= 0 && Number.isInteger(item.quantity) && item.quantity > 0 && item.quantity <= 99);
  if (!items.length) return null;
  return { ...value, restaurantName: String(value.restaurantName || 'Restaurant démo'), deliveryFee: Number.isFinite(value.deliveryFee) && value.deliveryFee >= 0 ? value.deliveryFee : 0, delivery: value.delivery !== false, items };
}
function orders() {
  const value = getStore('orders', []);
  if (!Array.isArray(value)) return [];
  return value.filter(order => order && order.demo === true && typeof order.id === 'string' && typeof order.restaurantName === 'string' && ['delivery', 'pickup'].includes(order.mode) && Array.isArray(order.items) && order.items.every(item => item && typeof item.name === 'string' && Number.isInteger(item.quantity) && item.quantity > 0 && Number.isFinite(item.price)));
}
function courierProfile() {
  const value = getStore('courier', null);
  return value && typeof value.id === 'string' && typeof value.name === 'string' && value.name.trim() && typeof value.city === 'string' && typeof value.vehicle === 'string' ? value : null;
}
function trimRequired(form, names) {
  for (const name of names) {
    const field = form.elements[name];
    if (!field) continue;
    field.value = field.value.trim();
  }
}
function saveOrders(value) {
  const saved = setStore('orders', value);
  window.dispatchEvent(new CustomEvent('yallah:orders'));
  if (saved === false) toast('La commande test n’a pas pu être enregistrée. Vérifiez le stockage de votre navigateur.');
  return saved !== false;
}
function normalizePhone(phone) {
  const normalized = String(phone || '').replace(/[\s().-]/g, '');
  return /^\+?\d{8,15}$/.test(normalized) ? normalized : null;
}
function phoneField(form, name = 'phone') {
  const field = form.elements[name];
  const phone = normalizePhone(field.value);
  field.setCustomValidity(phone ? '' : 'Saisissez un numéro de téléphone valide (8 à 15 chiffres).');
  field.oninput = () => field.setCustomValidity('');
  return phone;
}
function mapLink(restaurant) {
  const lat = Number(restaurant.lat), lng = Number(restaurant.lng);
  const query = Number.isFinite(lat) && Number.isFinite(lng) ? `${lat},${lng}` : restaurant.address;
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query || restaurant.name)}`;
}

export function openRestaurant(restaurant) {
  currentRestaurant = restaurant;
  const phone = normalizePhone(restaurant.phone);
  const cart = readCart();
  const count = cart?.items?.reduce((sum, item) => sum + item.quantity, 0) || 0;
  const menu = Array.isArray(restaurant.menu) ? restaurant.menu : [];
  const d = mount(restaurant.name, `
    <div class="d-restaurant-hero"><img src="${e(restaurant.cover || restaurant.image)}" alt="${e(restaurant.cuisine || restaurant.name)}"/><span class="d-photo-tag">${restaurant.demo ? 'Adresse de démonstration' : 'Données OpenStreetMap'}</span></div>
    <div class="d-rest-meta"><span>${e(restaurant.cuisine || 'Restaurant')}</span>${restaurant.score ? `<span>★ ${e(restaurant.score)} <small>(${e(restaurant.reviews || 0)} avis démo)</small></span>` : ''}<span>${restaurant.demo ? `${e(restaurant.eta || '25–35 min')} · ${restaurant.delivery ? 'Livraison' : 'À emporter'}` : 'Disponibilité à confirmer'}</span></div>
    <p class="d-description">${e(restaurant.description || 'Découvrez cette adresse et contactez directement l’établissement pour connaître sa carte et ses services.')}</p>
    <div class="d-address">${icon('pin')}<span>${e(restaurant.address || 'Adresse non renseignée')}</span></div>
    <div class="d-link-row"><a class="d-button d-outline" href="${mapLink(restaurant)}" target="_blank" rel="noopener noreferrer">${icon('pin')} Itinéraire</a>${phone && !restaurant.demo ? `<a class="d-button d-primary" href="tel:${e(phone)}">${icon('phone')} ${e(restaurant.phone)}</a>` : '<span class="d-phone-empty">Téléphone non renseigné</span>'}</div>
    ${restaurant.demo ? notice('Mode démo · Ce restaurant, son menu et ses tarifs sont des exemples. Les commandes test ne sont transmises à personne.') : notice('Les informations publiques peuvent être incomplètes. Confirmez le menu, les horaires et la livraison auprès du restaurant.')}
    <div class="d-section-heading"><h3>À la carte</h3><span>${menu.length ? `${menu.length} choix gourmands` : 'Carte à venir'}</span></div>
    ${menu.length ? `<div class="d-menu">${menu.map(item => `<article class="d-menu-item"><div class="d-menu-copy"><h4>${e(item.name)}</h4><p>${e(item.description || '')}</p><strong>${money(item.price)}</strong></div>${item.image ? `<img src="${e(item.image)}" alt="${e(item.name)}"/>` : ''}${restaurant.demo ? `<button type="button" class="d-add" data-add="${e(item.id)}" aria-label="Ajouter ${e(item.name)} au panier">+</button>` : ''}</article>`).join('')}</div>` : `<div class="d-empty d-empty-small"><span class="d-empty-icon">${icon('bag')}</span><h3>Le menu n’est pas encore disponible</h3><p>${phone ? 'Appelez le restaurant pour découvrir les plats et passer votre commande.' : 'Cette adresse n’a pas encore renseigné sa carte ni son numéro. Vous pouvez consulter sa localisation.'}</p></div>`}
    ${restaurant.demo ? `<div class="d-sticky-cart">${button(`${icon('bag')} Voir mon panier <span class="d-cart-count">${count}</span>`, 'cart')}</div>` : ''}
  `, { wide: true, subtitle: restaurant.demo ? 'Une bonne adresse à découvrir dans la démo.' : 'Une adresse près de vous.' });
  d.querySelector('[data-action="cart"]')?.addEventListener('click', openCart);
  d.querySelectorAll('[data-add]').forEach(node => {
    node.onclick = () => {
      const item = menu.find(entry => String(entry.id) === node.dataset.add);
      if (!item) return;
      let next = readCart();
      if (next?.restaurantId && next.restaurantId !== restaurant.id && next.items?.length) {
        const previous = next.restaurantName;
        mount('Changer de restaurant ?', `<p class="d-description">Votre panier contient des plats de ${e(previous)}. Une commande test concerne un seul restaurant.</p>${notice('Le panier précédent sera remplacé si vous continuez.')}<div class="d-actions">${button('Garder mon panier', 'keep', 'outline')}${button('Commencer ce panier', 'replace')}</div>`);
        modal().querySelector('[data-action="keep"]').onclick = () => openRestaurant(restaurant);
        modal().querySelector('[data-action="replace"]').onclick = () => {
          if (!updateCart({ restaurantId: restaurant.id, restaurantName: restaurant.name, deliveryFee: Number(restaurant.deliveryFee) || 0, delivery: !!restaurant.delivery, items: [{ id: item.id, name: item.name, price: Number(item.price), quantity: 1 }] })) return;
          openRestaurant(restaurant);
          toast(`${item.name} ajouté au panier`);
        };
        return;
      }
      if (!next?.items?.length) next = { restaurantId: restaurant.id, restaurantName: restaurant.name, deliveryFee: Number(restaurant.deliveryFee) || 0, delivery: !!restaurant.delivery, items: [] };
      const existing = next.items.find(entry => entry.id === item.id);
      if (existing && existing.quantity >= 99) return toast('Vous pouvez ajouter jusqu’à 99 exemplaires du même plat.');
      if (existing) existing.quantity += 1;
      else next.items.push({ id: item.id, name: item.name, price: Number(item.price), quantity: 1 });
      if (!updateCart(next)) return;
      const badge = d.querySelector('.d-cart-count');
      if (badge) badge.textContent = next.items.reduce((sum, entry) => sum + entry.quantity, 0);
      toast(`${item.name} ajouté au panier`);
    };
  });
}

export function openCart(selectedMode = 'delivery') {
  // DOM listeners pass an Event; only explicit mode strings may change checkout.
  selectedMode = selectedMode === 'pickup' ? 'pickup' : 'delivery';
  const cart = readCart();
  if (!cart?.items?.length) {
    const d = mount('Mon panier', `<div class="d-empty"><span class="d-empty-icon">${icon('bag')}</span><h3>On se fait plaisir ?</h3><p>Votre prochaine bonne découverte vous attend. Choisissez un restaurant et ajoutez vos plats préférés.</p>${button('Découvrir les restaurants', 'browse')}</div>`);
    d.querySelector('[data-action="browse"]').onclick = () => d.close();
    return;
  }
  const mode = cart.delivery === false ? 'pickup' : selectedMode;
  const subtotal = cart.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const fee = mode === 'delivery' ? Number(cart.deliveryFee) || 0 : 0;
  const savedProfile = getStore('checkout', {});
  const profile = savedProfile && typeof savedProfile === 'object' ? savedProfile : {};
  const d = mount('Un petit bonheur en panier', `
    <div class="d-cart-restaurant"><span class="d-mini-label">VOTRE COMMANDE CHEZ</span><strong>${e(cart.restaurantName)}</strong><span class="d-demo-pill">Commande test</span></div>
    <div class="d-cart-items">${cart.items.map(item => `<div class="d-cart-item"><div><h4>${e(item.name)}</h4><span>${money(item.price)}</span></div><div class="d-quantity"><button type="button" data-qty="${e(item.id)}" data-delta="-1" aria-label="Retirer un ${e(item.name)}">−</button><span>${item.quantity}</span><button type="button" data-qty="${e(item.id)}" data-delta="1" aria-label="Ajouter un ${e(item.name)}">+</button></div><strong>${money(item.price * item.quantity)}</strong></div>`).join('')}</div>
    <div class="d-mode" role="group" aria-label="Mode de retrait">${cart.delivery !== false ? `<button type="button" data-mode="delivery" aria-pressed="${mode === 'delivery'}" class="${mode === 'delivery' ? 'active' : ''}">${icon('bike')} Livraison</button>` : ''}<button type="button" data-mode="pickup" aria-pressed="${mode === 'pickup'}" class="${mode === 'pickup' ? 'active' : ''}">${icon('bag')} À emporter</button></div>
    <form id="checkout-form" class="d-form"><div class="d-form-grid"><label>Votre prénom<input name="name" autocomplete="given-name" required minlength="2" maxlength="80" value="${e(profile.name || '')}" placeholder="Ex. Salma"/></label><label>Téléphone<input name="phone" type="tel" autocomplete="tel" required maxlength="25" value="${e(profile.phone || '')}" placeholder="06 00 00 00 00"/></label></div>${mode === 'delivery' ? `<label>Adresse de livraison<input name="address" autocomplete="street-address" required minlength="8" maxlength="240" value="${e(profile.address || '')}" placeholder="Rue, numéro, étage et quartier"/></label>` : '<p class="d-field-help">Retrait au restaurant · Aucun frais de livraison.</p>'}<label>Une précision ? <span class="d-optional">facultatif</span><textarea name="notes" rows="2" maxlength="400" placeholder="Sans oignons, code de la porte…"></textarea></label>
    <div class="d-totals"><div><span>Sous-total</span><span>${money(subtotal)}</span></div><div><span>${mode === 'delivery' ? 'Livraison estimée' : 'Retrait au restaurant'}</span><span>${fee ? money(fee) : 'Gratuit'}</span></div><div class="d-total"><strong>Total</strong><strong>${money(subtotal + fee)}</strong></div></div>
    ${notice('Démo uniquement · Aucun paiement ni commande réelle. Vos informations et votre commande test restent dans ce navigateur.')}
    <button type="submit" class="d-button d-primary d-full">Confirmer ma commande test ${icon('arrow')}</button></form>
    <button type="button" class="d-text-button d-clear-cart" data-action="clear">Vider mon panier</button>
  `, { subtitle: 'Encore quelques détails, et c’est parti.' });
  d.querySelectorAll('[data-qty]').forEach(node => {
    node.onclick = () => {
      const item = cart.items.find(entry => String(entry.id) === node.dataset.qty);
      if (!item) return;
      if (Number(node.dataset.delta) > 0 && item.quantity >= 99) return toast('Vous pouvez ajouter jusqu’à 99 exemplaires du même plat.');
      item.quantity += Number(node.dataset.delta);
      cart.items = cart.items.filter(entry => entry.quantity > 0);
      if (!updateCart(cart.items.length ? cart : null)) return;
      openCart(mode);
    };
  });
  const preserveForm = () => {
    const form = d.querySelector('#checkout-form');
    setStore('checkout', { name: form.elements.name.value, phone: form.elements.phone.value, address: form.elements.address?.value || profile.address || '' });
  };
  d.querySelectorAll('[data-mode]').forEach(node => { node.onclick = () => { preserveForm(); openCart(node.dataset.mode); }; });
  d.querySelector('[data-action="clear"]').onclick = () => { if (updateCart(null)) openCart(); };
  d.querySelector('#checkout-form').onsubmit = event => {
    event.preventDefault();
    const form = event.currentTarget;
    trimRequired(form, ['name', 'address']);
    const phone = phoneField(form);
    if (!form.reportValidity() || !phone) return;
    preserveForm();
    const newOrder = { id: `YE-${Date.now().toString(36).toUpperCase()}`, createdAt: new Date().toISOString(), restaurantId: cart.restaurantId, restaurantName: cart.restaurantName, items: cart.items.map(item => ({ ...item })), subtotal, deliveryFee: fee, total: subtotal + fee, mode, name: form.elements.name.value.trim(), phone, address: form.elements.address?.value.trim() || 'Retrait au restaurant', notes: form.elements.notes.value.trim(), status: 'confirmed', courierId: null, demo: true };
    if (!saveOrders([newOrder, ...orders()])) return;
    updateCart(null);
    const success = mount('C’est parti pour le test !', `<div class="d-empty d-success"><span class="d-empty-icon">${icon('check')}</span><h3>Commande test enregistrée</h3><p><strong>${e(newOrder.id)}</strong><br/>${e(newOrder.restaurantName)} · ${money(newOrder.total)}</p>${notice('Aucune commande réelle n’a été passée. Cette simulation est enregistrée uniquement sur cet appareil.')}<div class="d-actions">${button('Suivre ma commande', 'orders')}${mode === 'delivery' ? button('Tester le côté livreur', 'courier', 'outline') : ''}</div></div>`);
    success.querySelector('[data-action="orders"]').onclick = openOrders;
    success.querySelector('[data-action="courier"]')?.addEventListener('click', openCourier);
  };
}

const statusInfo = {
  confirmed: ['Commande enregistrée', 'Votre commande test est prête à être prise en charge.'],
  preparing: ['Livreur en route au restaurant', 'Votre livreur de démonstration se rend au restaurant.'],
  picked_up: ['C’est en chemin !', 'La commande test a été récupérée. Prochaine étape : la livraison.'],
  delivered: ['Livraison terminée', 'Le parcours de livraison de démonstration est terminé.'],
};

export function openOrders() {
  const list = orders();
  const d = mount('Mes commandes', `
    ${list.length ? `${notice('Historique de démonstration · Visible uniquement sur cet appareil. Aucune commande n’a été envoyée à un restaurant.')}<div class="d-orders">${list.map(order => {
      const info = statusInfo[order.status] || statusInfo.confirmed;
      const stage = ['confirmed', 'preparing', 'picked_up', 'delivered'].indexOf(order.status);
      return `<article class="d-order"><div class="d-order-top"><span class="d-mini-label">${e(order.id)}</span><time datetime="${e(order.createdAt)}">${e(new Date(order.createdAt).toLocaleDateString('fr-MA', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }))}</time></div><h3>${e(order.restaurantName)}</h3><div class="d-order-detail">${order.items.map(item => `${item.quantity} × ${e(item.name)}`).join(' · ')}</div><div class="d-order-bottom"><span>${order.mode === 'delivery' ? 'Livraison' : 'À emporter'}</span><strong>${money(order.total)}</strong></div>${order.mode === 'delivery' ? `<div class="d-progress" aria-label="Étape ${stage + 1} sur 4">${[0, 1, 2, 3].map(index => `<span class="${index <= stage ? 'complete' : ''}"></span>`).join('')}</div><div class="d-order-status"><span class="d-status-dot"></span><div><strong>${e(info[0])}</strong><p>${e(info[1])}</p></div></div>` : '<div class="d-order-status"><span class="d-status-dot"></span><div><strong>Retrait test enregistré</strong><p>La simulation s’arrête ici. Aucun restaurant n’a reçu cette commande.</p></div></div>'}</article>`;
    }).join('')}</div><div class="d-actions">${button('Espace livreur démo', 'courier', 'outline')}</div>` : `<div class="d-empty"><span class="d-empty-icon">${icon('bag')}</span><h3>Le début d’une belle histoire</h3><p>Vos commandes test apparaîtront ici. Commencez par découvrir un menu et composer votre panier.</p>${button('Découvrir un menu', 'menu')}</div>`}
  `, { subtitle: 'Toutes vos envies, au même endroit.' });
  d.querySelector('[data-action="menu"]')?.addEventListener('click', () => restaurants[0] ? openRestaurant(restaurants[0]) : d.close());
  d.querySelector('[data-action="courier"]')?.addEventListener('click', openCourier);
}

export function openCourier() {
  const profile = courierProfile();
  if (profile) return courierDashboard(profile);
  const d = mount('Roulez avec Yallah Eat', `
    <div class="d-courier-intro"><span class="d-empty-icon">${icon('bike')}</span><div><h3>Votre ville. Votre rythme.</h3><p>Découvrez le parcours livreur et testez votre première mission.</p></div></div>
    ${notice('Espace de démonstration · Votre inscription crée un profil local sur cet appareil. Elle ne constitue pas une embauche et ne donne accès à aucune livraison réelle.')}
    <form id="courier-form" class="d-form"><label>Nom complet<input name="name" autocomplete="name" required minlength="3" maxlength="100" placeholder="Votre prénom et votre nom"/></label><div class="d-form-grid"><label>Téléphone<input name="phone" type="tel" autocomplete="tel" required maxlength="25" placeholder="06 00 00 00 00"/></label><label>Ville<select name="city" required><option value="Casablanca">Casablanca</option><option value="Rabat">Rabat</option><option value="Marrakech">Marrakech</option><option value="Tanger">Tanger</option><option value="Agadir">Agadir</option><option value="Fès">Fès</option><option value="Autre">Autre ville</option></select></label></div><label>Votre moyen de transport<select name="vehicle" required><option value="Scooter">Scooter / moto</option><option value="Vélo">Vélo</option><option value="Voiture">Voiture</option></select></label><label class="d-check-label"><input type="checkbox" name="terms" required/><span>Je comprends que ce profil et les missions sont des simulations enregistrées uniquement dans mon navigateur.</span></label><button type="submit" class="d-button d-primary d-full">Créer mon profil démo ${icon('arrow')}</button></form>
    <p class="d-footnote">Pour devenir livreur dans une version commerciale, une vérification et un service de répartition réels devront être mis en place.</p>
  `, { subtitle: 'Un espace pensé pour les livreurs.' });
  d.querySelector('#courier-form').onsubmit = event => {
    event.preventDefault();
    const form = event.currentTarget;
    trimRequired(form, ['name']);
    const phone = phoneField(form);
    if (!form.reportValidity() || !phone) return;
    const next = { id: `courier-${Date.now().toString(36)}`, name: form.elements.name.value.trim(), phone, city: form.elements.city.value, vehicle: form.elements.vehicle.value, online: false, createdAt: new Date().toISOString(), demo: true };
    if (setStore('courier', next) === false) return toast('Le profil n’a pas pu être enregistré. Vérifiez le stockage de votre navigateur.');
    courierDashboard(next);
  };
}

function courierDashboard(profile) {
  const all = orders();
  const own = all.filter(order => order.courierId === profile.id && order.status !== 'delivered');
  const available = all.filter(order => order.mode === 'delivery' && order.status === 'confirmed' && !order.courierId);
  const completed = all.filter(order => order.courierId === profile.id && order.status === 'delivered');
  const mission = (order, active) => `<article class="d-mission"><div class="d-order-top"><span class="d-mini-label">${e(order.id)}</span><span class="d-demo-pill">Mission test</span></div><h3>${e(order.restaurantName)}</h3><div class="d-mission-route"><div><span class="d-route-point"></span><p><small>RÉCUPÉRER CHEZ</small><strong>${e(order.restaurantName)}</strong></p></div><div><span class="d-route-point d-route-destination"></span><p><small>LIVRER À</small><strong>${e(order.address)}</strong></p></div></div><p class="d-field-help">${order.items.reduce((sum, item) => sum + item.quantity, 0)} articles · ${e(order.name)}</p>${active ? `<button type="button" class="d-button d-primary d-full" data-mission="${e(order.id)}" data-status="${order.status === 'preparing' ? 'picked_up' : 'delivered'}">${order.status === 'preparing' ? 'Confirmer le retrait test' : 'Terminer la livraison test'} ${icon('check')}</button>` : `<button type="button" class="d-button d-primary d-full" data-claim="${e(order.id)}" ${!profile.online ? 'disabled' : ''}>Accepter la mission test ${icon('arrow')}</button>`}</article>`;
  const d = mount('Mon espace livreur', `
    <div class="d-profile"><div class="d-avatar">${e(profile.name.charAt(0).toUpperCase())}</div><div><h3>Salam, ${e(profile.name.split(' ')[0])} !</h3><p>${e(profile.city)} · ${e(profile.vehicle)}</p></div><span class="d-demo-pill">Démo</span></div>
    <div class="d-online"><div><strong>${profile.online ? 'Vous êtes disponible' : 'Vous êtes hors ligne'}</strong><span>${profile.online ? 'Prêt pour une mission de démonstration.' : 'Activez votre disponibilité pour accepter un test.'}</span></div><button type="button" class="d-switch ${profile.online ? 'active' : ''}" role="switch" aria-checked="${!!profile.online}" aria-label="Disponible pour les missions test" data-action="online"><span></span></button></div>
    <div class="d-courier-stats"><div><strong>${completed.length}</strong><span>Livraisons test terminées</span></div><div><strong>${own.length}</strong><span>Mission${own.length > 1 ? 's' : ''} en cours</span></div></div>
    ${notice('Simulation sur cet appareil · Les missions proviennent de vos propres commandes test. Aucun revenu ni aucune livraison réelle ne sont générés.')}
    ${own.length ? `<div class="d-section-heading"><h3>Ma mission en cours</h3></div>${own.map(order => mission(order, true)).join('')}` : ''}
    <div class="d-section-heading"><h3>Missions disponibles</h3><span>${available.length} mission${available.length > 1 ? 's' : ''} test</span></div>
    ${available.length ? available.map(order => mission(order, false)).join('') : `<div class="d-empty d-empty-small"><span class="d-empty-icon">${icon('bike')}</span><h3>Votre prochaine mission commence ici</h3><p>Passez une commande test avec livraison pour essayer le parcours complet du livreur.</p>${button('Créer une commande test', 'menu', 'outline')}</div>`}
    <p class="d-footnote">Vos coordonnées et votre historique restent dans ce navigateur.</p>
  `, { subtitle: 'Prêt à prendre la route ?' });
  d.querySelector('[data-action="online"]').onclick = () => {
    const next = { ...profile, online: !profile.online };
    if (setStore('courier', next) === false) return toast('Votre disponibilité n’a pas pu être enregistrée.');
    courierDashboard(next);
  };
  d.querySelector('[data-action="menu"]')?.addEventListener('click', () => restaurants[0] ? openRestaurant(restaurants[0]) : d.close());
  d.querySelectorAll('[data-claim]').forEach(node => { node.onclick = () => {
    const latestProfile = courierProfile();
    if (!latestProfile?.online) return courierDashboard(latestProfile || profile);
    const latest = orders();
    const order = latest.find(entry => entry.id === node.dataset.claim);
    if (!order || order.status !== 'confirmed' || order.courierId) return courierDashboard(latestProfile);
    if (latest.some(entry => entry.courierId === latestProfile.id && entry.status !== 'delivered')) return toast('Terminez votre mission en cours avant d’en accepter une autre.');
    order.courierId = latestProfile.id;
    order.status = 'preparing';
    if (!saveOrders(latest)) return;
    courierDashboard(latestProfile);
  }; });
  d.querySelectorAll('[data-mission]').forEach(node => { node.onclick = () => {
    const latest = orders();
    const order = latest.find(entry => entry.id === node.dataset.mission && entry.courierId === profile.id);
    if (!order) return;
    if (order.status === 'preparing' && node.dataset.status === 'picked_up') order.status = 'picked_up';
    else if (order.status === 'picked_up' && node.dataset.status === 'delivered') { order.status = 'delivered'; order.deliveredAt = new Date().toISOString(); }
    else return;
    if (!saveOrders(latest)) return;
    courierDashboard(profile);
    if (order.status === 'delivered') toast('Parcours test terminé. Merci, et bonne route !');
  }; });
}

export function openPartner() {
  const savedDraft = getStore('partner', {});
  const draft = savedDraft && typeof savedDraft === 'object' ? savedDraft : {};
  const d = mount('Votre restaurant, tout près d’eux', `
    <p class="d-description">Un snack de quartier, une recette de famille ou votre nouvelle table : préparez votre fiche pour rejoindre l’aventure Yallah Eat.</p>
    ${notice('Brouillon de démonstration · Cette fiche reste sur votre appareil. Elle n’est ni envoyée ni publiée dans l’annuaire.')}
    <form id="partner-form" class="d-form"><label>Nom du restaurant<input name="name" required minlength="2" maxlength="100" value="${e(draft.name || '')}" placeholder="Le nom de votre établissement"/></label><div class="d-form-grid"><label>Type de cuisine<select name="cuisine" required>${['Marocain', 'Burgers', 'Pizza', 'Tacos', 'Sushi', 'Healthy', 'Autre'].map(value => `<option ${draft.cuisine === value ? 'selected' : ''}>${value}</option>`).join('')}</select></label><label>Téléphone professionnel<input name="phone" type="tel" required maxlength="25" value="${e(draft.phone || '')}" placeholder="05 22 00 00 00"/></label></div><label>Adresse complète<input name="address" required minlength="8" maxlength="240" value="${e(draft.address || '')}" placeholder="Rue, quartier et ville"/></label><label>Votre menu<textarea name="menu" rows="4" required minlength="8" maxlength="4000" placeholder="Un plat et son prix par ligne.\nEx. : Tajine poulet — 65 DH">${e(draft.menu || '')}</textarea></label><label class="d-check-label"><input type="checkbox" name="delivery" ${draft.delivery ? 'checked' : ''}/><span>Mon restaurant propose la livraison.</span></label><button type="submit" class="d-button d-primary d-full">Enregistrer mon brouillon ${icon('check')}</button></form>
  `, { subtitle: 'Les bonnes adresses commencent avec vous.' });
  d.querySelector('#partner-form').onsubmit = event => {
    event.preventDefault();
    const form = event.currentTarget;
    trimRequired(form, ['name', 'address', 'menu']);
    const phone = phoneField(form);
    if (!form.reportValidity() || !phone) return;
    if (setStore('partner', { name: form.elements.name.value.trim(), cuisine: form.elements.cuisine.value, phone, address: form.elements.address.value.trim(), menu: form.elements.menu.value.trim(), delivery: form.elements.delivery.checked, savedAt: new Date().toISOString() }) === false) return toast('Le brouillon n’a pas pu être enregistré. Vérifiez le stockage de votre navigateur.');
    mount('Votre brouillon est prêt', `<div class="d-empty d-success"><span class="d-empty-icon">${icon('check')}</span><h3>Une belle adresse à partager</h3><p>La fiche de <strong>${e(form.elements.name.value)}</strong> est enregistrée sur cet appareil. Vous pourrez la modifier en ouvrant à nouveau cet espace.</p>${notice('Votre restaurant n’a pas été publié. La validation des partenaires et la publication nécessitent un service réel.')}<div class="d-actions">${button('Modifier ma fiche', 'edit', 'outline')}${button('Terminé', 'done')}</div></div>`);
    modal().querySelector('[data-action="edit"]').onclick = openPartner;
    modal().querySelector('[data-action="done"]').onclick = () => modal().close();
  };
}
