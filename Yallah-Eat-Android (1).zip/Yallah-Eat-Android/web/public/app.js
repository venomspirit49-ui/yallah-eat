import { images } from './media.js';
import { restaurants, districts, money, escapeHTML, getStore, setStore, haversine } from './data.js';
import { openRestaurant, openCart, openCourier, openOrders, openPartner } from './dialogs.js';

const paths = {
  pin:'<path d="M20 10c0 6-8 11-8 11S4 16 4 10a8 8 0 1 1 16 0Z"/><circle cx="12" cy="10" r="2.5"/>',
  search:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 4.5 4.5"/>',
  bag:'<path d="M5 7h14l1 14H4L5 7Z"/><path d="M8 8V6a4 4 0 0 1 8 0v2"/>',
  bike:'<circle cx="5" cy="17" r="4"/><circle cx="19" cy="17" r="4"/><path d="m5 17 5-10 6 10H5m3-10h5m2-4h3l1 14"/>',
  grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  map:'<path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2V5Zm6-2v16m6-14v16"/>',
  clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 1 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
  star:'<path d="m12 2 3.1 6.4 7 1-5 5 .9 7-6-3.3-6.2 3.3 1.2-7-5-5 6.8-1L12 2Z"/>',
  gps:'<circle cx="12" cy="12" r="6.5"/><circle cx="12" cy="12" r="2"/><path d="M12 2v3m0 14v3M2 12h3m14 0h3"/>',
  fork:'<path d="M5 3v6a3 3 0 0 0 6 0V3M8 3v19m10-19c-5 4-5 9 0 10V3Zm0 10v9"/>'
};
const icon = name => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.fork}</svg>`;
const $ = id => document.getElementById(id);
const e = value => escapeHTML(String(value ?? ''));
const normalize = value => String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
const state = { category:'Tout', query:'', delivery:false, open:false, sort:'recommended', view:'list', nav:'explore', limit:6, mode:'demo', location:districts[0], nearby:[], busy:false };
let favorites = getStore('favorites', []);
if (!Array.isArray(favorites)) favorites = [];
let realSaved = getStore('realSaved', []);
if (!Array.isArray(realSaved)) realSaved = [];
realSaved=realSaved.filter(r=>r&&typeof r.id==='string'&&typeof r.name==='string'&&typeof r.cuisine==='string'&&Array.isArray(r.menu)&&Number.isFinite(r.lat)&&Number.isFinite(r.lng));

function toast(message) {
  const node=$('toast'); node.textContent=message; node.hidden=false;
  clearTimeout(toast.timer); toast.timer=setTimeout(()=>{ node.hidden=true; },4200);
}
window.addEventListener('yallah:toast',event=>toast(event.detail?.message || event.detail || 'Impossible d’enregistrer sur cet appareil.'));
for (const [id,name] of [['cart-icon','bag'],['search-icon','search'],['hero-bike','bike'],['delivery-icon','bike'],['gps-icon','gps'],['list-view','grid'],['map-view','map']]) $(id).innerHTML=icon(name);
document.querySelector('.pin-icon').innerHTML=icon('pin');
document.querySelector('.tiny-pin').innerHTML=icon('pin');

const categoryConfig=[['Tout',null],['Burgers','burger'],['Pizza','pizza'],['Marocain','tagine'],['Sushi','sushi'],['Tacos','tacos'],['Healthy','bowl']];
function renderCategories() {
  $('categories').innerHTML=categoryConfig.map(([name,photo])=>`<button class="category ${state.category===name?'active':''}" data-category="${name}" aria-pressed="${state.category===name}"><span class="category-image">${photo?`<img src="${images[photo]}" alt="" loading="lazy">`:icon('fork')}</span>${name==='Tout'?'Toutes les envies':name}</button>`).join('');
}
function distance(r) {return haversine(state.location.lat,state.location.lng,r.lat,r.lng);}
function fmtDistance(r) {const d=distance(r);return d<1?`${Math.max(50,Math.round(d*1000/50)*50)} m`:`${d.toFixed(1).replace('.',',')} km`;}
function list() {
  let source=state.mode==='real'?state.nearby:restaurants;
  if(state.nav==='favorites') source=[...new Map([...restaurants,...realSaved,...state.nearby].map(r=>[r.id,r])).values()].filter(r=>favorites.includes(r.id));
  let filtered=source.filter(r=>{
    const searchable=normalize([r.name,r.cuisine,r.address,...r.menu.map(m=>m.name)].join(' '));
    return (state.category==='Tout'||r.category===state.category)&&(!state.query||searchable.includes(normalize(state.query)))&&(!state.delivery||r.delivery===true)&&(!state.open||r.open===true);
  });
  if(state.sort==='distance')filtered.sort((a,b)=>distance(a)-distance(b));
  if(state.sort==='rating')filtered.sort((a,b)=>(b.score||0)-(a.score||0));
  if(state.sort==='fee')filtered.sort((a,b)=>(a.deliveryFee??9999)-(b.deliveryFee??9999));
  return filtered;
}
function restaurantCard(r) {
  const favorite=favorites.includes(r.id);
  const status=r.demo?(r.open?'Ouvert · démo':'Fermé · démo'):'Horaires à confirmer';
  return `<article class="restaurant-card" data-restaurant="${e(r.id)}"><div class="card-photo"><img src="${e(r.image)}" alt="${e(r.demo?r.category:r.name)}" loading="lazy">${r.badge?`<span class="card-badge ${r.category==='Pizza'||r.category==='Tacos'?'orange':''}">${e(r.badge)}</span>`:''}<button class="favorite-button ${favorite?'selected':''}" data-favorite="${e(r.id)}" aria-label="${favorite?'Retirer':'Ajouter'} ${e(r.name)} ${favorite?'des':'aux'} favoris" aria-pressed="${favorite}">${icon('heart')}</button><span class="card-open"><i></i>${status}</span></div><div class="card-body"><div class="card-title-row"><h3 class="restaurant-name"><button data-open="${e(r.id)}">${e(r.name)}</button></h3><span class="card-rating">${r.score?`${icon('star')}${r.score.toFixed(1)} <small>(${r.reviews})</small>`:'<small>Adresse locale</small>'}</span></div><p class="card-cuisine">${e(r.cuisine)}</p><div class="card-meta"><span>${icon('clock')}${e(r.eta||'À confirmer')}</span><span>${icon('pin')}${fmtDistance(r)}</span><span class="delivery-price">${r.demo?(r.delivery?`${icon('bike')}${r.deliveryFee?money(r.deliveryFee):'Livraison offerte'}`:'À emporter'):'Menu à renseigner'}</span></div></div></article>`;
}
function findRestaurant(id) {return [...restaurants,...state.nearby,...realSaved].find(r=>r.id===id);}
function renderMap(rows) {
  if(state.view!=='map')return;
  const center=rows[0]||state.location;
  const lat=Number(center.lat),lng=Number(center.lng);
  const bbox=[lng-.026,lat-.018,lng+.026,lat+.018].join(',');
  const url=`https://www.openstreetmap.org/export/embed.html?bbox=${encodeURIComponent(bbox)}&layer=mapnik&marker=${lat}%2C${lng}`;
  $('map-panel').innerHTML=`<iframe title="Carte du quartier et de la première adresse affichée" src="${url}" loading="lazy" referrerpolicy="no-referrer"></iframe><div class="map-caption"><span>${state.mode==='demo'?'Positions indicatives de démonstration.':'La carte indique la première adresse de la liste.'}</span><a href="https://www.openstreetmap.org/?mlat=${lat}&mlon=${lng}#map=15/${lat}/${lng}" target="_blank" rel="noopener noreferrer">Ouvrir la carte ↗</a></div>`;
}
function render() {
  renderCategories();
  const rows=list();
  document.querySelectorAll('[data-nav]').forEach(button=>button.classList.toggle('active',button.dataset.nav===state.nav));
  $('results-title').innerHTML=state.nav==='favorites'?'Vos adresses à garder au chaud<span>.</span>':state.mode==='real'?'De bonnes adresses autour de vous<span>.</span>':'Les bonnes adresses du coin<span>.</span>';
  $('results-subtitle').textContent=state.nav==='favorites'?'Vos favoris, sauvegardés sur cet appareil':state.mode==='real'?'Adresses OpenStreetMap dans un rayon de 3,5 km':'Notre sélection de démonstration à Casablanca';
  $('results-count').textContent=`${rows.length} adresse${rows.length!==1?'s':''} ${state.query?'pour « '+state.query+' »':'à découvrir'}`;
  $('restaurant-grid').innerHTML=rows.slice(0,state.limit).map(restaurantCard).join('')||`<div class="empty-state">${icon(state.nav==='favorites'?'heart':'search')}<h3>${state.nav==='favorites'?'Vos coups de cœur se retrouvent ici.':'Pas encore d’adresse pour cette envie.'}</h3><p>${state.nav==='favorites'?'Touchez le cœur d’un restaurant pour le garder à portée de main.':'Essayez une autre cuisine ou retirez les filtres pour explorer les adresses disponibles.'}</p><button id="reset-empty">${state.nav==='favorites'?'Explorer les restaurants':'Voir toutes les adresses'}</button></div>`;
  $('more-row').hidden=rows.length<=state.limit;
  $('delivery-filter').classList.toggle('active',state.delivery);$('delivery-filter').setAttribute('aria-pressed',String(state.delivery));
  $('open-filter').classList.toggle('active',state.open);$('open-filter').setAttribute('aria-pressed',String(state.open));
  $('all-mode').classList.toggle('active',!state.delivery&&!state.open);
  $('delivery-filter').disabled=state.mode==='real'&&state.nav!=='favorites';
  $('open-filter').disabled=state.mode==='real'&&state.nav!=='favorites';
  $('delivery-filter').title=state.mode==='real'?'Disponibilité de la livraison à confirmer auprès du restaurant':'';
  $('open-filter').title=state.mode==='real'?'Horaires à confirmer auprès du restaurant':'';
  $('list-view').classList.toggle('active',state.view==='list');$('list-view').setAttribute('aria-pressed',String(state.view==='list'));
  $('map-view').classList.toggle('active',state.view==='map');$('map-view').setAttribute('aria-pressed',String(state.view==='map'));
  $('map-panel').hidden=state.view!=='map';renderMap(rows);
  $('location-label').textContent=state.location.name;
  if(state.mode==='real') {
    $('source-notice').hidden=false;
    $('source-notice').innerHTML='Adresses issues d’OpenStreetMap. Menus, horaires, téléphone et livraison peuvent être absents ou nécessiter confirmation. <button id="back-demo">Revenir à la sélection démo</button>';
  } else $('source-notice').hidden=true;
  document.querySelector('#reset-empty')?.addEventListener('click',()=>{state.category='Tout';state.query='';state.delivery=false;state.open=false;state.nav='explore';$('search-input').value='';state.limit=6;render();});
  document.querySelector('#back-demo')?.addEventListener('click',()=>setDistrict(districts[0]));
}
function updateCartCount() {
  const cart=getStore('cart',null);
  const count=Array.isArray(cart?.items)?cart.items.reduce((sum,item)=>sum+(Number(item.quantity)||0),0):0;
  $('cart-count').textContent=String(count);
  $('cart-button').setAttribute('aria-label',`Ouvrir le panier, ${count} article${count!==1?'s':''}`);
}
$('categories').addEventListener('click',event=>{const button=event.target.closest('[data-category]');if(!button)return;state.category=button.dataset.category;state.limit=6;render();});
$('restaurant-grid').addEventListener('click',event=>{
  const heart=event.target.closest('[data-favorite]');
  if(heart){
    const id=heart.dataset.favorite;const wasSaved=favorites.includes(id);
    const next=wasSaved?favorites.filter(item=>item!==id):[...favorites,id];
    if(!setStore('favorites',next)){toast('Le stockage de cet appareil n’est pas disponible.');return;}
    favorites=next;
    const restaurant=findRestaurant(id);
    if(restaurant&&!restaurant.demo&&!wasSaved){realSaved=[...realSaved.filter(r=>r.id!==id),restaurant];setStore('realSaved',realSaved);}
    toast(wasSaved?'Adresse retirée des favoris.':'Une bonne adresse bien gardée !');render();return;
  }
  const card=event.target.closest('[data-restaurant]');if(card){const restaurant=findRestaurant(card.dataset.restaurant);if(restaurant)openRestaurant(restaurant);}
});
$('search-form').addEventListener('submit',event=>{event.preventDefault();state.query=$('search-input').value.trim();state.limit=6;render();$('restaurants').scrollIntoView({behavior:'smooth'});});
$('search-input').addEventListener('input',()=>{state.query=$('search-input').value.trim();state.limit=6;render();});
document.querySelectorAll('[data-nav]').forEach(button=>button.addEventListener('click',()=>{state.nav=button.dataset.nav;state.category='Tout';state.query='';state.delivery=false;state.open=false;$('search-input').value='';state.limit=6;render();$('restaurants').scrollIntoView({behavior:'smooth'});}));
$('all-mode').onclick=()=>{state.delivery=false;state.open=false;state.limit=6;render();};
$('delivery-filter').onclick=()=>{state.delivery=!state.delivery;state.limit=6;render();};
$('open-filter').onclick=()=>{state.open=!state.open;state.limit=6;render();};
$('sort-select').onchange=()=>{state.sort=$('sort-select').value;render();};
$('list-view').onclick=()=>{state.view='list';render();};
$('map-view').onclick=()=>{state.view='map';render();};
$('show-more').onclick=()=>{state.limit+=6;render();};
$('cart-button').onclick=openCart;$('orders-button').onclick=openOrders;
$('courier-button').onclick=openCourier;$('courier-cta').onclick=openCourier;$('partner-button').onclick=openPartner;
window.addEventListener('yallah:cart',updateCartCount);
window.addEventListener('storage',()=>{const savedFavorites=getStore('favorites',[]),savedRestaurants=getStore('realSaved',[]);favorites=Array.isArray(savedFavorites)?savedFavorites.filter(id=>typeof id==='string'):[];realSaved=Array.isArray(savedRestaurants)?savedRestaurants.filter(r=>r&&typeof r.id==='string'&&typeof r.name==='string'&&typeof r.cuisine==='string'&&Array.isArray(r.menu)&&Number.isFinite(r.lat)&&Number.isFinite(r.lng)):[];render();updateCartCount();});

function setDistrict(district) {
  state.location=district;state.mode='demo';state.category='Tout';state.limit=6;state.query='';state.nav='explore';state.delivery=false;state.open=false;$('search-input').value='';render();
}
$('district-list').innerHTML=districts.map((district,index)=>`<button class="district-button" data-district="${index}">${e(district.name)}<span>↗</span></button>`).join('');
$('district-list').onclick=event=>{const button=event.target.closest('[data-district]');if(button){setDistrict(districts[Number(button.dataset.district)]);$('location-dialog').close();toast('Quartier mis à jour. Les distances de la démo sont recalculées.');}};
$('location-button').onclick=()=>$('location-dialog').showModal();
$('close-location').onclick=()=>$('location-dialog').close();
$('location-dialog').addEventListener('click',event=>{if(event.target===$('location-dialog'))$('location-dialog').close();});

function osmCategory(tags) {
  const cuisine=normalize(tags.cuisine||'');
  if(/burger/.test(cuisine))return 'Burgers';if(/pizza|italian/.test(cuisine))return 'Pizza';if(/moroccan|regional|arab/.test(cuisine))return 'Marocain';if(/sushi|japanese|asian/.test(cuisine))return 'Sushi';if(/taco|kebab|shawarma|sandwich/.test(cuisine))return 'Tacos';if(/vegan|vegetarian|salad/.test(cuisine))return 'Healthy';return 'Autre';
}
async function loadNearby(lat,lng) {
  const query=`[out:json][timeout:18];nwr(around:3500,${lat.toFixed(6)},${lng.toFixed(6)})[amenity~"^(restaurant|fast_food|cafe|food_court)$"][name];out center 80;`;
  const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),24000);
  try {
    const response=await fetch('https://overpass-api.de/api/interpreter?data='+encodeURIComponent(query),{signal:controller.signal});
    if(!response.ok)throw new Error('Le service de recherche est momentanément indisponible.');
    const data=await response.json();
    if(!Array.isArray(data.elements))throw new Error('Réponse de recherche invalide.');
    return data.elements.map(item=>{
      const t=item.tags||{};const category=osmCategory(t);const photo={Burgers:'burger',Pizza:'pizza',Marocain:'tagine',Sushi:'sushi',Tacos:'tacos',Healthy:'bowl'}[category]||'restaurant';
      const street=[t['addr:housenumber'],t['addr:street']].filter(Boolean).join(' ');
      return {id:`osm-${item.type}-${item.id}`,name:t.name,cuisine:(t.cuisine|| (t.amenity==='fast_food'?'Snack':t.amenity==='cafe'?'Café':'Restaurant')).replaceAll(';',' · ').replaceAll('_',' '),category,image:images[photo],cover:images[photo],score:null,reviews:0,eta:null,deliveryFee:null,lat:item.lat??item.center?.lat,lng:item.lon??item.center?.lon,address:[street,t['addr:suburb'],t['addr:city']].filter(Boolean).join(', ')||'Adresse précise à vérifier sur la carte',phone:t.phone||t['contact:phone']||null,delivery:null,open:null,badge:'OpenStreetMap',description:'Adresse provenant d’OpenStreetMap. Photo d’illustration. Confirmez les horaires, le menu, les prix et la livraison directement auprès de l’établissement.',menu:[],demo:false};
    }).filter(r=>Number.isFinite(r.lat)&&Number.isFinite(r.lng));
  }finally{clearTimeout(timer);}
}
async function locate() {
  if(state.busy)return;
  if(!navigator.geolocation){toast('Le GPS n’est pas disponible dans ce navigateur. Choisissez un quartier pour la démo.');return;}
  if($('location-dialog').open)$('location-dialog').close();
  state.busy=true;$('gps-button').classList.add('gps-loading');$('gps-button').disabled=true;
  toast('Localisation en cours… Autorisez le GPS dans votre navigateur.');
  try {
    const position=await new Promise((resolve,reject)=>navigator.geolocation.getCurrentPosition(resolve,reject,{enableHighAccuracy:false,timeout:15000,maximumAge:60000}));
    const {latitude:lat,longitude:lng}=position.coords;
    toast('On cherche les bonnes adresses autour de vous…');
    const nearby=await loadNearby(lat,lng);
    state.location={name:'Autour de vous',lat,lng};state.nearby=nearby;state.mode='real';state.nav='explore';state.category='Tout';state.query='';state.delivery=false;state.open=false;state.sort='distance';state.limit=6;$('search-input').value='';$('sort-select').value='distance';render();
    toast(nearby.length?`${nearby.length} adresses trouvées à proximité.`:'Aucune adresse répertoriée à moins de 3,5 km.');$('restaurants').scrollIntoView({behavior:'smooth'});
  } catch(error) {
    const message=error.code===1?'Accès à la position refusé. Vous pouvez choisir un quartier pour explorer la démo.':error.code===2?'Position introuvable. Réessayez ou choisissez un quartier.':error.code===3?'La localisation prend trop de temps. Réessayez ou choisissez un quartier.':error.name==='AbortError'?'La recherche a expiré. Réessayez dans un instant.':error.message==='Failed to fetch'?'La recherche d’adresses est indisponible. La sélection démo reste accessible.':error.message;
    toast(message||'La recherche est indisponible. Vous pouvez réessayer.');
  }finally{state.busy=false;$('gps-button').classList.remove('gps-loading');$('gps-button').disabled=false;}
}
$('gps-button').onclick=locate;$('location-gps').onclick=locate;
render();updateCartCount();
