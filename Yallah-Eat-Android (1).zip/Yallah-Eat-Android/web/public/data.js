import { images } from './media.js';
// Fictional catalogue used to explore the Yallah Eat demo. No restaurant,
// rating, menu, opening state, delivery time or delivery fee here is verified.
export const restaurants = [
  {
    id: 'bun-beldi',
    name: 'Bun & Beldi',
    cuisine: 'Burgers · American · Fait maison',
    category: 'Burgers',
    image: images.burger,
    cover: images.burger,
    score: 4.8, reviews: 126, eta: '20–30 min', deliveryFee: 10,
    lat: 33.5826, lng: -7.6332,
    address: 'Quartier Maârif, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: true,
    badge: 'Le choix du quartier',
    description: 'Des smash burgers généreux, du pain moelleux et des sauces maison. Une adresse fictive pour découvrir Yallah Eat.',
    demo: true,
    menu: [
      { id: 'bb-classic', name: 'Classic Smash', description: 'Bœuf, cheddar, pickles, oignons et sauce maison.', price: 49 },
      { id: 'bb-double', name: 'Double Beldi', description: 'Double steak, double cheddar et sauce légèrement épicée.', price: 65 },
      { id: 'bb-chicken', name: 'Crispy Chicken', description: 'Poulet croustillant, salade fraîche et mayonnaise citronnée.', price: 45 },
      { id: 'bb-fries', name: 'Frites maison', description: 'Pommes de terre dorées, sel et paprika.', price: 18 }
    ]
  },
  {
    id: 'pizza-cortile',
    name: 'Pizza Cortile',
    cuisine: 'Pizza · Italien · Four à pierre',
    category: 'Pizza',
    image: images.pizza,
    cover: images.pizza,
    score: 4.7, reviews: 94, eta: '25–35 min', deliveryFee: 12,
    lat: 33.5895, lng: -7.6307,
    address: 'Quartier Gauthier, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: true,
    badge: 'À découvrir',
    description: 'Une pâte fine, une sauce tomate parfumée et des pizzas à partager. Restaurant de démonstration.',
    demo: true,
    menu: [
      { id: 'pc-margherita', name: 'Margherita', description: 'Tomate, mozzarella, basilic frais et huile d’olive.', price: 55 },
      { id: 'pc-four-cheese', name: 'Quatre fromages', description: 'Mozzarella, bleu, chèvre et emmental.', price: 75 },
      { id: 'pc-chicken', name: 'Poulet pesto', description: 'Poulet grillé, pesto, mozzarella et champignons.', price: 69 },
      { id: 'pc-tiramisu', name: 'Tiramisu', description: 'Crème mascarpone, café et cacao.', price: 30 }
    ]
  },
  {
    id: 'dar-lbenna',
    name: 'Dar Lbenna',
    cuisine: 'Marocain · Tajines · Cuisine de famille',
    category: 'Marocain',
    image: images.tagine,
    cover: images.tagine,
    score: 4.9, reviews: 208, eta: '30–40 min', deliveryFee: 15,
    lat: 33.5788, lng: -7.6384,
    address: 'Quartier Maârif, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: true,
    badge: 'Saveurs de chez nous',
    description: 'Les recettes du dimanche, les épices qui réchauffent et le goût de la maison. Restaurant fictif de démonstration.',
    demo: true,
    menu: [
      { id: 'dl-tagine-chicken', name: 'Tajine poulet citron', description: 'Poulet mijoté, citron confit et olives vertes.', price: 65 },
      { id: 'dl-tagine-beef', name: 'Tajine kefta', description: 'Kefta, tomate, œuf et pain marocain.', price: 59 },
      { id: 'dl-couscous', name: 'Couscous aux légumes', description: 'Semoule légère, sept légumes et pois chiches.', price: 55 },
      { id: 'dl-harira', name: 'Harira maison', description: 'Soupe traditionnelle, dattes et citron.', price: 20 }
    ]
  },
  {
    id: 'nori-atelier',
    name: 'Nori Atelier',
    cuisine: 'Sushi · Japonais · Bowls',
    category: 'Sushi',
    image: images.sushi,
    cover: images.sushi,
    score: 4.6, reviews: 82, eta: '30–45 min', deliveryFee: 15,
    lat: 33.5962, lng: -7.6489,
    address: 'Quartier Anfa, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: true,
    badge: '',
    description: 'Des rolls colorés, des produits frais et des assortiments à partager. Adresse fictive de démonstration.',
    demo: true,
    menu: [
      { id: 'na-california', name: 'California saumon · 8 pièces', description: 'Saumon, avocat, riz vinaigré et sésame.', price: 59 },
      { id: 'na-crunchy', name: 'Crunchy crevettes · 8 pièces', description: 'Crevettes croustillantes, concombre et sauce épicée.', price: 65 },
      { id: 'na-box', name: 'Box découverte · 16 pièces', description: 'Un assortiment de makis et de California rolls.', price: 109 },
      { id: 'na-edamame', name: 'Edamame', description: 'Fèves de soja, fleur de sel et citron.', price: 25 }
    ]
  },
  {
    id: 'tacos-lab',
    name: 'Tacos Lab',
    cuisine: 'Tacos · Snacks · Sauce fromagère',
    category: 'Tacos',
    image: images.tacos,
    cover: images.tacos,
    score: 4.5, reviews: 156, eta: '15–25 min', deliveryFee: 8,
    lat: 33.5801, lng: -7.6273,
    address: 'Quartier Maârif, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: true,
    badge: 'Petit prix, grand appétit',
    description: 'Des tacos gratinés et des snacks pour les grosses faims. Restaurant fictif de démonstration.',
    demo: true,
    menu: [
      { id: 'tl-chicken', name: 'Tacos poulet', description: 'Poulet mariné, frites et sauce fromagère.', price: 35 },
      { id: 'tl-mixte', name: 'Tacos mixte', description: 'Poulet et viande hachée, frites et sauce au choix.', price: 45 },
      { id: 'tl-gratine', name: 'Tacos gratiné', description: 'Poulet, cheddar gratiné, frites et sauce maison.', price: 49 },
      { id: 'tl-drink', name: 'Citronnade maison', description: 'Citron pressé, eau fraîche et menthe.', price: 15 }
    ]
  },
  {
    id: 'green-ritual',
    name: 'Green Ritual',
    cuisine: 'Healthy · Salades · Bowls',
    category: 'Healthy',
    image: images.bowl,
    cover: images.bowl,
    score: 4.8, reviews: 73, eta: '20–30 min', deliveryFee: 10,
    lat: 33.5881, lng: -7.6369,
    address: 'Quartier Gauthier, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: true,
    badge: 'Une pause fraîcheur',
    description: 'Des bowls complets et des assiettes pleines de couleurs pour le déjeuner. Adresse fictive de démonstration.',
    demo: true,
    menu: [
      { id: 'gr-chicken', name: 'Bowl poulet avocat', description: 'Poulet grillé, quinoa, avocat, crudités et sauce yaourt.', price: 59 },
      { id: 'gr-falafel', name: 'Bowl falafels', description: 'Falafels, houmous, boulgour, concombre et tahini.', price: 49 },
      { id: 'gr-salad', name: 'Salade méditerranéenne', description: 'Feta, tomate, olives, concombre et herbes fraîches.', price: 45 },
      { id: 'gr-smoothie', name: 'Smoothie vert', description: 'Épinards, pomme, banane et citron.', price: 29 }
    ]
  },
  {
    id: 'comptoir-souk',
    name: 'Le Comptoir du Souk',
    cuisine: 'Marocain · Grillades · Sandwichs',
    category: 'Marocain',
    image: images.tagine,
    cover: images.tagine,
    score: 4.7, reviews: 112, eta: 'Sur place', deliveryFee: 0,
    lat: 33.5991, lng: -7.6224,
    address: 'Ancienne Médina, Casablanca · Adresse de démonstration',
    phone: null, delivery: false, open: true,
    badge: '',
    description: 'Brochettes, pain chaud et petites assiettes à partager sur place. Restaurant fictif de démonstration.',
    demo: true,
    menu: [
      { id: 'cs-kefta', name: 'Assiette kefta grillée', description: 'Kefta, salade marocaine, frites et pain chaud.', price: 55 },
      { id: 'cs-skewers', name: 'Brochettes de poulet', description: 'Poulet mariné aux épices, riz et légumes.', price: 59 },
      { id: 'cs-bocadillo', name: 'Bocadillo beldi', description: 'Thon, œuf, pommes de terre et olives.', price: 25 },
      { id: 'cs-tea', name: 'Thé à la menthe', description: 'Thé vert à la menthe fraîche.', price: 12 }
    ]
  },
  {
    id: 'slice-club',
    name: 'Slice Club',
    cuisine: 'Pizza · Street food · À partager',
    category: 'Pizza',
    image: images.pizza,
    cover: images.pizza,
    score: 4.4, reviews: 61, eta: '25–40 min', deliveryFee: 12,
    lat: 33.5946, lng: -7.6678,
    address: 'Quartier Aïn Diab, Casablanca · Adresse de démonstration',
    phone: null, delivery: true, open: false,
    badge: '',
    description: 'De grandes pizzas à découper entre amis et une sélection de snacks. Adresse fictive de démonstration.',
    demo: true,
    menu: [
      { id: 'sc-veggie', name: 'Veggie Club', description: 'Poivrons, champignons, olives, tomate et mozzarella.', price: 59 },
      { id: 'sc-pepperoni', name: 'Pepperoni', description: 'Tomate, mozzarella et pepperoni de bœuf.', price: 69 },
      { id: 'sc-bbq', name: 'Chicken BBQ', description: 'Poulet, oignons rouges, mozzarella et sauce barbecue.', price: 75 },
      { id: 'sc-garlic', name: 'Garlic bread', description: 'Pain à l’ail gratiné, à partager.', price: 25 }
    ]
  }
];

export const districts = [
  { name: 'Maârif, Casablanca', lat: 33.5815, lng: -7.6338 },
  { name: 'Gauthier, Casablanca', lat: 33.5895, lng: -7.6320 },
  { name: 'Anfa, Casablanca', lat: 33.5960, lng: -7.6485 },
  { name: 'Aïn Diab, Casablanca', lat: 33.5945, lng: -7.6675 },
  { name: 'Ancienne Médina, Casablanca', lat: 33.5990, lng: -7.6207 }
];

export function money(value) {
  const amount = Number(value);
  return `${new Intl.NumberFormat('fr-MA', { maximumFractionDigits: 2 }).format(Number.isFinite(amount) ? amount : 0)} DH`;
}

export function escapeHTML(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[char]);
}

export function getStore(key, fallback = null) {
  try {
    const raw = localStorage.getItem(`yallah:${key}`);
    return raw === null ? fallback : JSON.parse(raw);
  } catch {
    return fallback;
  }
}

export function setStore(key, value) {
  try {
    localStorage.setItem(`yallah:${key}`, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

export function haversine(lat1, lng1, lat2, lng2) {
  const coordinates = [lat1, lng1, lat2, lng2].map(Number);
  if (!coordinates.every(Number.isFinite)) return Infinity;
  const [aLat, aLng, bLat, bLng] = coordinates;
  const radians = value => value * Math.PI / 180;
  const deltaLat = radians(bLat - aLat);
  const deltaLng = radians(bLng - aLng);
  const a = Math.sin(deltaLat / 2) ** 2
    + Math.cos(radians(aLat)) * Math.cos(radians(bLat)) * Math.sin(deltaLng / 2) ** 2;
  return 6371 * 2 * Math.asin(Math.sqrt(Math.min(1, Math.max(0, a))));
}
