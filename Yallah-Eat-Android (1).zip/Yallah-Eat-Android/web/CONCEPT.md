# Yallah Eat — Concept produit

## La promesse

**Trouver quoi manger près de soi, consulter un menu fiable et choisir comment recevoir sa commande.** Yallah Eat rassemble restaurants, snacks, cafés et cuisines locales dans une application mobile accessible aussi depuis un navigateur. Le lancement se concentre sur Casablanca, quartier par quartier, avant une extension aux villes où le catalogue et les opérations de livraison sont prêts.

L’application propose deux niveaux de présence : les **adresses issues d’un annuaire ouvert**, utiles pour découvrir un établissement et le contacter, et les **restaurants partenaires vérifiés**, qui renseignent leurs menus, leurs horaires et leurs possibilités de commande. Une adresse trouvée sur une carte ne devient pas automatiquement un partenaire proposant la livraison.

## Quatre espaces complémentaires

**Client.** Le client utilise le GPS ou saisit une ville et un quartier. Il explore une liste ou une carte, recherche un plat ou un établissement et filtre par cuisine, budget, horaires et livraison lorsque ces informations sont connues. Chaque fiche indique la distance, l’adresse, les coordonnées disponibles, le menu daté et les conditions de livraison. Il peut enregistrer ses favoris et retrouver ses commandes.

**Restaurant ou snack.** Le responsable inscrit son établissement, fournit ses coordonnées et définit ses horaires, sa zone de service et son mode de livraison. Après vérification, il gère son menu, les prix, les photos et les produits indisponibles. Il accepte ou refuse les commandes, annonce un délai de préparation et signale les fermetures exceptionnelles.

**Livreur indépendant.** Le livreur dépose sa candidature, indique sa ville, son véhicule et sa zone de travail. Après les vérifications nécessaires au lancement du service, il active sa disponibilité, consulte les missions éligibles et leur rémunération annoncée, puis accepte une livraison. Son espace rassemble les étapes de la mission, l’historique et les montants à recevoir.

**Administration.** L’équipe vérifie les établissements et les candidatures, corrige les informations signalées et supervise les commandes. Elle définit les zones, les frais, les commissions et les règles d’attribution, puis traite les annulations, les réclamations et les règlements.

## Le parcours client

1. **Localiser.** Le client choisit sa position et voit uniquement les informations connues pour cette zone. Le refus du GPS reste compatible avec une recherche manuelle.
2. **Choisir.** Il consulte le menu, les prix, les horaires et la disponibilité. Les données absentes sont indiquées explicitement. Les photos illustratives sont distinguées des photos de l’établissement.
3. **Commander.** Deux parcours sont possibles : contacter directement un restaurant par téléphone ou WhatsApp, lorsque ce canal est confirmé, ou commander dans l’application auprès d’un partenaire équipé.
4. **Recevoir.** Pour une commande intégrée, le client choisit le retrait ou une livraison proposée à son adresse, vérifie le total détaillé et confirme. Il reçoit ensuite les mises à jour du restaurant et du livreur.

Une commande passée par téléphone ou WhatsApp reste gérée directement avec le restaurant. Elle n’apparaît comme une livraison suivie par Yallah Eat que si elle est enregistrée et acceptée dans le système.

## Commande et livraison intégrées

Le panier contient les produits d’un seul établissement. Avant confirmation, il affiche les articles, options, quantités, frais de livraison et éventuels frais de service. Les minimums de commande et les zones couvertes sont configurables et visibles avant l’engagement du client.

Le cycle prévu est : **envoyée → acceptée par le restaurant → en préparation → prête → récupérée → livrée**. L’attribution du livreur possède son propre état : **en recherche → mission proposée → acceptée**. Une mission ne peut être acceptée simultanément par plusieurs livreurs. Un refus du restaurant, une annulation ou une absence de livreur déclenche un statut explicite et une solution proposée au client.

Le restaurant peut livrer avec sa propre équipe ou utiliser les livreurs Yallah Eat. L’application affiche le mode réellement disponible. Pour les missions de la plateforme, l’attribution tient compte de la zone, de la disponibilité et de la capacité du livreur. Le montant et les points de retrait et de livraison sont présentés avant acceptation.

Le livreur confirme le retrait, puis la remise au client selon une méthode définie, par exemple un code de livraison. La géolocalisation en mission permet ensuite une estimation de progression. Les coordonnées personnelles sont accessibles uniquement aux intervenants concernés et pendant la durée utile au service.

## Modèle économique et paiement

Le modèle peut combiner une commission sur les commandes intégrées, des frais de livraison et des services optionnels pour les restaurants. Ces montants restent configurables : aucun tarif universel n’est fixé par ce concept. Les établissements sponsorisés sont identifiés clairement et ne remplacent pas les critères de proximité ou de disponibilité.

Le paiement à la livraison constitue une première option de lancement, avec un processus précis de suivi des espèces et de règlement des partenaires. Le paiement en ligne est ajouté avec un prestataire adapté au marché, incluant confirmation, remboursement et rapprochement des transactions. Les gains des livreurs reposent sur les missions effectivement réalisées et sur des règles annoncées.

## Première version opérationnelle

Le MVP couvre une zone limitée de Casablanca avec un catalogue vérifié, la recherche par quartier et GPS, les menus, les contacts, les favoris et les demandes de commande. Un premier groupe de restaurants et de livreurs permet ensuite d’ouvrir les commandes intégrées, le paiement à la livraison et une attribution supervisée. Les notifications, le suivi en mission, les paiements en ligne et l’extension géographique viennent après validation de ce fonctionnement.

La mise en service nécessite un stockage partagé durable, des comptes avec autorisations par rôle, une gestion simultanée des commandes, des notifications et un tableau de supervision. Elle nécessite aussi des partenaires actifs, une organisation de support et des règles concrètes pour les annulations, les incidents et les règlements.

## État de la démo actuelle

La démo présente huit établissements fictifs de Casablanca et leurs menus fictifs. La recherche GPS peut afficher des adresses réelles provenant d’OpenStreetMap, sans garantir leurs menus, horaires, numéros ou services de livraison.

Les paniers, commandes d’essai, profils de livreurs et brouillons de restaurants restent enregistrés dans le navigateur de l’appareil utilisé. Le parcours livreur simule la prise en charge et la livraison des commandes d’essai de cet appareil. **Aucune commande réelle n’est transmise et aucune mission réelle n’est attribuée.** Cette démo valide l’expérience avant le raccordement des partenaires et du système partagé.
