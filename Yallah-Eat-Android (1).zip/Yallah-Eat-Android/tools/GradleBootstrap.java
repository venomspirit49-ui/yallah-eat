import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.channels.*;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.*;
import java.util.zip.*;

/** Small source-mode launcher; deliberately not a copy of the official wrapper JAR. */
public final class GradleBootstrap {
    private static final String VERSION = "8.13";
    private static final String DISTRIBUTION = "https://services.gradle.org/distributions/gradle-8.13-bin.zip";
    private static final Set<String> HOSTS = Set.of("services.gradle.org", "downloads.gradle.org", "github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com");
    private static final long ZIP_LIMIT = 300L * 1024 * 1024;
    private static final long EXTRACT_LIMIT = 1024L * 1024 * 1024;
    private static final class Failure extends IOException { Failure(String message) { super(message); } }

    public static void main(String[] args) {
        try {
            if (Runtime.version().feature() < 17) throw new Failure("A full JDK 17 or newer is required.");
            if (Arrays.asList(args).contains("--bootstrap-help")) {
                System.out.println("Yallah Eat Gradle launcher (custom, Java source mode).\nRequires JDK 17+. Downloads official Gradle 8.13 and verifies its published SHA-256.\nUsage: ./gradlew :app:assembleDebug\n--check-runtime checks Java without downloading anything.\nAndroid Studio can read gradle/wrapper/gradle-wrapper.properties directly.");
                return;
            }
            if (Arrays.asList(args).contains("--check-runtime")) {
                System.out.println("Java " + Runtime.version().feature() + " ready; Gradle and Android SDK have not been checked.");
                return;
            }
            Path root = Path.of(System.getProperty("yallah.project.dir", ".")).toAbsolutePath().normalize();
            Properties properties = new Properties();
            try (InputStream in = Files.newInputStream(root.resolve("gradle/wrapper/gradle-wrapper.properties"))) { properties.load(in); }
            if (!DISTRIBUTION.equals(properties.getProperty("distributionUrl"))) throw new Failure("Unexpected Gradle distribution. This launcher supports only the pinned official Gradle 8.13 URL.");
            String configuredHome = System.getenv("GRADLE_USER_HOME");
            Path cache = (configuredHome == null || configuredHome.isBlank() ? Path.of(System.getProperty("user.home"), ".gradle") : Path.of(configuredHome)).toAbsolutePath().resolve("yallah-bootstrap");
            Files.createDirectories(cache);
            Path installation = cache.resolve("gradle-" + VERSION);
            boolean windows = System.getProperty("os.name").toLowerCase(Locale.ROOT).contains("win");
            String executable = windows ? "gradle.bat" : "gradle";
            try (FileChannel channel = FileChannel.open(cache.resolve("bootstrap.lock"), StandardOpenOption.CREATE, StandardOpenOption.WRITE); FileLock ignored = channel.lock()) {
                if (Files.isSymbolicLink(installation)) throw new Failure("The Gradle cache must not be a symbolic link.");
                if (!Files.isRegularFile(installation.resolve(".yallah-verified")) || !Files.isRegularFile(installation.resolve("bin/" + executable))) install(cache, installation, executable);
            }
            Path launcher = installation.resolve("bin/" + executable);
            List<String> command = new ArrayList<>();
            if (windows) {
                List<String> values = new ArrayList<>(List.of(launcher.toString())); values.addAll(List.of(args));
                for (String value : values) if (invalidWindowsArgument(value)) throw new Failure("Windows launcher arguments cannot contain double quotes, percent signs or newlines; use an installed Gradle for those arguments.");
                String line = values.stream().map(value -> "\"" + value + "\"").reduce((left, right) -> left + " " + right).orElseThrow();
                command.addAll(List.of("cmd.exe", "/d", "/v:off", "/s", "/c", "\"" + line + "\""));
            } else { command.add(launcher.toString()); command.addAll(List.of(args)); }
            int result = new ProcessBuilder(command).directory(root.toFile()).inheritIO().start().waitFor();
            System.exit(result);
        } catch (Exception error) {
            String detail = error instanceof Failure ? error.getMessage() : "Check the JDK, cache permissions, network/proxy connection and available disk space (" + error.getClass().getSimpleName() + ").";
            System.err.println("Gradle bootstrap failed: " + detail);
            System.exit(1);
        }
    }

    private static boolean invalidWindowsArgument(String value) {
        return value.contains("\"") || value.contains("%") || value.contains("\r") || value.contains("\n");
    }

    private static HttpClient client() throws Failure {
        HttpClient.Builder builder = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30)).followRedirects(HttpClient.Redirect.NEVER);
        if (System.getProperty("https.proxyHost") == null) {
            String proxy = System.getenv("HTTPS_PROXY");
            if (proxy == null || proxy.isBlank()) proxy = System.getenv("https_proxy");
            if (proxy == null || proxy.isBlank()) proxy = System.getenv("HTTP_PROXY");
            if (proxy != null && !proxy.isBlank()) {
                try {
                    URI parsed = URI.create(proxy);
                    if (parsed.getHost() == null || !"http".equalsIgnoreCase(parsed.getScheme()) || parsed.getUserInfo() != null) throw new IllegalArgumentException();
                    builder.proxy(ProxySelector.of(InetSocketAddress.createUnresolved(parsed.getHost(), parsed.getPort() < 0 ? 80 : parsed.getPort())));
                } catch (IllegalArgumentException error) { throw new Failure("The environment proxy must be an HTTP proxy without embedded credentials. Configure authenticated proxies through JVM settings."); }
            }
        }
        return builder.build();
    }

    private static InputStream download(HttpClient client, URI start) throws Exception {
        URI uri = start;
        for (int redirect = 0; redirect < 8; redirect++) {
            if (!"https".equalsIgnoreCase(uri.getScheme()) || !HOSTS.contains(String.valueOf(uri.getHost()).toLowerCase(Locale.ROOT)) || uri.getUserInfo() != null || (uri.getPort() != -1 && uri.getPort() != 443)) throw new Failure("The distribution redirected outside the trusted HTTPS download hosts.");
            HttpResponse<InputStream> response = client.send(HttpRequest.newBuilder(uri).timeout(Duration.ofMinutes(5)).header("User-Agent", "YallahEat-GradleBootstrap/1").GET().build(), HttpResponse.BodyHandlers.ofInputStream());
            if (response.statusCode() == 200) return response.body();
            response.body().close();
            if (Set.of(301, 302, 303, 307, 308).contains(response.statusCode())) {
                Optional<String> location = response.headers().firstValue("location");
                if (location.isEmpty()) throw new Failure("The download server returned a redirect without a destination.");
                uri = uri.resolve(location.get());
            } else throw new Failure("The download server returned HTTP " + response.statusCode() + ".");
        }
        throw new Failure("The download exceeded the redirect limit.");
    }

    private static void install(Path cache, Path installation, String executable) throws Exception {
        HttpClient http = client();
        String expected;
        try (InputStream input = download(http, URI.create(DISTRIBUTION + ".sha256"))) {
            expected = new String(input.readNBytes(256), java.nio.charset.StandardCharsets.US_ASCII).trim();
            if (!expected.matches("[a-fA-F0-9]{64}")) throw new Failure("The official Gradle checksum response was invalid.");
        }
        System.out.println("Downloading official Gradle " + VERSION + " and verifying SHA-256…");
        Path archive = Files.createTempFile(cache, "gradle-", ".part");
        Path staging = Files.createTempDirectory(cache, "extract-");
        try {
            try (InputStream input = download(http, URI.create(DISTRIBUTION)); OutputStream output = Files.newOutputStream(archive)) { copy(input, output, ZIP_LIMIT); }
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream input = Files.newInputStream(archive)) { byte[] buffer = new byte[65536]; for (int n; (n = input.read(buffer)) >= 0;) digest.update(buffer, 0, n); }
            if (!HexFormat.of().formatHex(digest.digest()).equalsIgnoreCase(expected)) throw new Failure("Gradle checksum verification failed. No downloaded code was executed.");
            long remaining = EXTRACT_LIMIT;
            try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
                for (ZipEntry entry; (entry = zip.getNextEntry()) != null;) {
                    Path destination = staging.resolve(entry.getName()).normalize();
                    if (!destination.startsWith(staging) || !destination.startsWith(staging.resolve("gradle-" + VERSION)) || entry.getName().contains("\\")) throw new Failure("The distribution archive contained an unsafe path.");
                    if (entry.isDirectory()) Files.createDirectories(destination);
                    else {
                        Files.createDirectories(destination.getParent());
                        try (OutputStream output = Files.newOutputStream(destination, StandardOpenOption.CREATE_NEW)) { remaining -= copy(zip, output, remaining); }
                    }
                    zip.closeEntry();
                }
            }
            Path unpacked = staging.resolve("gradle-" + VERSION);
            Path launcher = unpacked.resolve("bin/" + executable);
            if (!Files.isRegularFile(launcher)) throw new Failure("The distribution did not contain the Gradle executable.");
            if (!executable.endsWith(".bat") && !launcher.toFile().setExecutable(true, true)) throw new Failure("Cannot mark the downloaded Gradle launcher executable.");
            Files.writeString(unpacked.resolve(".yallah-verified"), expected + "\n");
            deleteTree(installation);
            try { Files.move(unpacked, installation, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException unsupported) { Files.move(unpacked, installation); }
        } finally { Files.deleteIfExists(archive); deleteTree(staging); }
    }

    private static long copy(InputStream input, OutputStream output, long limit) throws IOException {
        long total = 0; byte[] buffer = new byte[65536];
        for (int count; (count = input.read(buffer)) >= 0;) {
            total += count; if (total > limit) throw new Failure("The distribution exceeded the allowed download or extraction size.");
            output.write(buffer, 0, count);
        }
        return total;
    }

    private static void deleteTree(Path directory) throws IOException {
        if (!Files.exists(directory, LinkOption.NOFOLLOW_LINKS)) return;
        try (var paths = Files.walk(directory)) { for (Path path : paths.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(path); }
    }
}
