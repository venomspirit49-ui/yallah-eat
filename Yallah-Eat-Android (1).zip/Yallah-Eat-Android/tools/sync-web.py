#!/usr/bin/env python3
"""Bundle a standalone Yallah Eat HTML export without a web server dependency."""
import argparse
import hashlib
import pathlib
import re


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('html', type=pathlib.Path, help='Path to outputs/Yallah-Eat.html')
    args = parser.parse_args()
    html = args.html.read_text(encoding='utf-8')
    if 'YallahData' not in html or 'YallahDialogs' not in html or '<html' not in html.lower():
        parser.error('Supply the standalone HTML export, not the modular public/index.html.')
    if re.search(r'<script[^>]+src=', html, flags=re.I):
        parser.error('The standalone export must contain its JavaScript inline.')

    # Android routes explicit top-level link taps to the dialer or browser.
    html = html.replace('target="_blank"', 'target="_self"')
    html = html.replace('width=device-width, initial-scale=1', 'width=device-width, initial-scale=1, viewport-fit=cover')
    css = '''<style id="android-adjustments">
    body { overscroll-behavior-y: none; }
    button, a { touch-action: manipulation; }
    .android-app-note { max-width:850px; margin:0 auto; padding:0 20px 22px;
      color:#7e827c; font-size:10px; line-height:1.8; }
    .android-app-note summary { color:#24553d; cursor:pointer; font-weight:700; }
    @media(max-width:600px) {
      .filter-chip { min-height:40px; font-size:11px; }
      .nav-link { font-size:12px; }
      .d-button { min-height:44px; }
      .favorite-button { width:36px; height:36px; }
      .android-app-note { padding-bottom:76px; }
    }
    </style>'''
    html = html.replace('</head>', css + '\n</head>', 1)
    note = '''<details class="android-app-note"><summary>À propos de cette version Android</summary>
    <p>Yallah Eat · Démonstration. Menus, favoris, panier et essais livreur sont intégrés à l’application.
    Aucune commande réelle n’est envoyée. Les coordonnées et profils saisis restent sur cet appareil.
    Effacez les données de l’application dans les réglages Android pour les supprimer.</p>
    <p>La position est facultative. Le GPS transmet votre position à OpenStreetMap/Overpass uniquement
    pour rechercher les adresses à proximité. La carte, les photos Unsplash et les polices Google
    nécessitent une connexion et contactent leurs fournisseurs. Les liens téléphone et itinéraire
    ouvrent les applications externes de votre téléphone. Aucun paiement ni suivi en arrière-plan.</p>
    </details>'''
    html = html.replace('</footer>', note + '\n</footer>', 1)
    destination = pathlib.Path(__file__).resolve().parents[1] / 'app/src/main/assets/index.html'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(html, encoding='utf-8')
    print(f'Bundled {destination.relative_to(destination.parents[4])}: {destination.stat().st_size} bytes')
    print(f'SHA-256 {hashlib.sha256(html.encode()).hexdigest()}')


if __name__ == '__main__':
    main()
